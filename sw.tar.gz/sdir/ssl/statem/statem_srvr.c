/*
 * Copyright 1995-2026 The OpenSSL Project Authors. All Rights Reserved.
 * Copyright (c) 2002, Oracle and/or its affiliates. All rights reserved
 * Copyright 2005 Nokia. All rights reserved.
 *
 * Licensed under the Apache License 2.0 (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */

#include "internal/e_os.h"

#include <stdio.h>
#include "../ssl_local.h"
#include "statem_local.h"
#include "internal/constant_time.h"
#include "internal/cryptlib.h"
#include "internal/ssl_unwrap.h"
#include "internal/sizes.h"
#include <openssl/buffer.h>
#include <openssl/rand.h>
#include <openssl/objects.h>
#include <openssl/evp.h>
#include <openssl/x509.h>
#include <openssl/dh.h>
#include <openssl/rsa.h>
#include <openssl/bn.h>
#include <openssl/md5.h>
#include <openssl/trace.h>
#include <openssl/core_names.h>
#include <openssl/asn1t.h>
#include <openssl/comp.h>
#include "internal/comp.h"
#include <openssl/ocsp.h>

#define TICKET_NONCE_SIZE 8

#ifndef OPENSSL_NO_ECH
#include "../ech/ech_local.h"
#endif

typedef struct {
    ASN1_TYPE *kxBlob;
    ASN1_TYPE *opaqueBlob;
} GOST_KX_MESSAGE;

DECLARE_ASN1_FUNCTIONS(GOST_KX_MESSAGE)

ASN1_SEQUENCE(GOST_KX_MESSAGE) = {
    ASN1_SIMPLE(GOST_KX_MESSAGE, kxBlob, ASN1_ANY),
    ASN1_OPT(GOST_KX_MESSAGE, opaqueBlob, ASN1_ANY),
} ASN1_SEQUENCE_END(GOST_KX_MESSAGE)

IMPLEMENT_ASN1_FUNCTIONS(GOST_KX_MESSAGE)

static CON_FUNC_RETURN tls_construct_encrypted_extensions(SSL_CONNECTION *s,
    WPACKET *pkt);

static ossl_inline int received_client_cert(const SSL_CONNECTION *sc)
{
    return sc->session->peer_rpk != NULL || sc->session->peer != NULL;
}

/*
 * ossl_statem_server13_read_transition() encapsulates the logic for the allowed
 * handshake state transitions when a TLSv1.3 server is reading messages from
 * the client. The message type that the client has sent is provided in |mt|.
 * The current state is in |s->statem.hand_state|.
 *
 * Return values are 1 for success (transition allowed) and  0 on error
 * (transition not allowed)
 */
static int ossl_statem_server13_read_transition(SSL_CONNECTION *s, int mt)
{
    OSSL_STATEM *st = &s->statem;

    if (st->hand_state == TLS_ST_SR_ACK) {
        st->hand_state = st->pre_ack_hand_state;
        if (mt == SSL3_MT_DUMMY)
            return 1;
    }

    /*
     * Note: There is no case for TLS_ST_BEFORE because at that stage we have
     * not negotiated TLSv1.3 yet, so that case is handled by
     * ossl_statem_server_read_transition()
     */
    switch (st->hand_state) {
    default:
        break;

    case TLS_ST_EARLY_DATA:
        if (s->hello_retry_request == SSL_HRR_PENDING) {
            if (mt == SSL3_MT_CLIENT_HELLO) {
                st->hand_state = TLS_ST_SR_CLNT_HELLO;
                return 1;
            }
            break;
            /*
             * RFC 9147 Section 5.6 states DTLS1.3 should omit the
             * End of Early Data Message
             */
        } else if (s->ext.early_data == SSL_EARLY_DATA_ACCEPTED
            && !SSL_NO_EOED(s)) {
            if (mt == SSL3_MT_END_OF_EARLY_DATA) {
                st->hand_state = TLS_ST_SR_END_OF_EARLY_DATA;
                return 1;
            }
            break;
        } else if (SSL_CONNECTION_IS_DTLS13(s) && s->ext.early_data == SSL_EARLY_DATA_ACCEPTED) {
            /*
             * Let DTLS1.3 fallthrough to the Finished processing below
             */
            s->early_data_state = SSL_EARLY_DATA_FINISHED_READING;
        }
        /* Fall through */

    case TLS_ST_SR_END_OF_EARLY_DATA:
    case TLS_ST_SW_FINISHED:
        if (s->s3.tmp.cert_request) {
            if (mt == SSL3_MT_CERTIFICATE) {
                st->hand_state = TLS_ST_SR_CERT;
                return 1;
            }
#ifndef OPENSSL_NO_COMP_ALG
            if (mt == SSL3_MT_COMPRESSED_CERTIFICATE
                && s->ext.compress_certificate_sent) {
                st->hand_state = TLS_ST_SR_COMP_CERT;
                return 1;
            }
#endif
        } else {
            if (mt == SSL3_MT_FINISHED) {
                st->hand_state = TLS_ST_SR_FINISHED;
                return 1;
            }
        }
        break;

    case TLS_ST_SR_COMP_CERT:
    case TLS_ST_SR_CERT:
        if (st->no_cert_verify || !received_client_cert(s)) {
            if (mt == SSL3_MT_FINISHED) {
                st->hand_state = TLS_ST_SR_FINISHED;
                return 1;
            }
        } else {
            if (mt == SSL3_MT_CERTIFICATE_VERIFY) {
                st->hand_state = TLS_ST_SR_CERT_VRFY;
                return 1;
            }
        }
        break;

    case TLS_ST_SR_CERT_VRFY:
        if (mt == SSL3_MT_FINISHED) {
            st->hand_state = TLS_ST_SR_FINISHED;
            return 1;
        }
        break;

    case TLS_ST_SW_KEY_UPDATE:
    case TLS_ST_SW_SESSION_TICKET:
        if (mt == DTLS13_MT_ACK) {
            st->pre_ack_hand_state = st->hand_state;
            st->hand_state = TLS_ST_SR_ACK;
            return 1;
        }
        break;

    case TLS_ST_OK:
        /*
         * Its never ok to start processing handshake messages in the middle of
         * early data (i.e. before we've received the end of early data alert)
         */
        if (s->early_data_state == SSL_EARLY_DATA_READING)
            break;

        if (s->post_handshake_auth == SSL_PHA_REQUESTED) {
            if (mt == SSL3_MT_CERTIFICATE) {
                st->hand_state = TLS_ST_SR_CERT;
                return 1;
            }
#ifndef OPENSSL_NO_COMP_ALG
            if (mt == SSL3_MT_COMPRESSED_CERTIFICATE
                && s->ext.compress_certificate_sent) {
                st->hand_state = TLS_ST_SR_COMP_CERT;
                return 1;
            }
#endif
        }

        if (mt == SSL3_MT_KEY_UPDATE && !SSL_IS_QUIC_HANDSHAKE(s)) {
            st->hand_state = TLS_ST_SR_KEY_UPDATE;
            return 1;
        }

        if (mt == DTLS13_MT_ACK) {
            st->pre_ack_hand_state = st->hand_state;
            st->hand_state = TLS_ST_SR_ACK;
            return 1;
        }
        break;
    }

    /* No valid transition found */
    return 0;
}

/*
 * ossl_statem_server_read_transition() encapsulates the logic for the allowed
 * handshake state transitions when the server is reading messages from the
 * client. The message type that the client has sent is provided in |mt|. The
 * current state is in |s->statem.hand_state|.
 *
 * Return values are 1 for success (transition allowed) and  0 on error
 * (transition not allowed)
 */
int ossl_statem_server_read_transition(SSL_CONNECTION *s, int mt)
{
    OSSL_STATEM *st = &s->statem;

    if (SSL_CONNECTION_IS_VERSION13(s)) {
        if (!ossl_statem_server13_read_transition(s, mt))
            goto err;
        return 1;
    }

    switch (st->hand_state) {
    default:
        break;

    case TLS_ST_BEFORE:
    case TLS_ST_OK:
    case DTLS_ST_SW_HELLO_VERIFY_REQUEST:
        if (mt == SSL3_MT_CLIENT_HELLO) {
            st->hand_state = TLS_ST_SR_CLNT_HELLO;
            return 1;
        }
        break;

    case TLS_ST_SW_SRVR_DONE:
        /*
         * If we get a CKE message after a ServerDone then either
         * 1) We didn't request a Certificate
         * OR
         * 2) We did request one and we allow no Certificate to be returned
         */
        if (mt == SSL3_MT_CLIENT_KEY_EXCHANGE) {
            if (!s->s3.tmp.cert_request) {
                st->hand_state = TLS_ST_SR_KEY_EXCH;
                return 1;
            }
        } else if (s->s3.tmp.cert_request) {
            if (mt == SSL3_MT_CERTIFICATE) {
                st->hand_state = TLS_ST_SR_CERT;
                return 1;
            }
        }
        break;

    case TLS_ST_SR_CERT:
        if (mt == SSL3_MT_CLIENT_KEY_EXCHANGE) {
            st->hand_state = TLS_ST_SR_KEY_EXCH;
            return 1;
        }
        break;

    case TLS_ST_SR_KEY_EXCH:
        /*
         * We should only process a CertificateVerify message if we have
         * received a Certificate from the client. If so then |s->session->peer|
         * will be non NULL. In some instances a CertificateVerify message is
         * not required even if the peer has sent a Certificate (e.g. such as in
         * the case of static DH). In that case |st->no_cert_verify| should be
         * set.
         */
        if (!received_client_cert(s) || st->no_cert_verify) {
            if (mt == SSL3_MT_CHANGE_CIPHER_SPEC) {
                /*
                 * For the ECDH ciphersuites when the client sends its ECDH
                 * pub key in a certificate, the CertificateVerify message is
                 * not sent. Also for GOST ciphersuites when the client uses
                 * its key from the certificate for key exchange.
                 */
                st->hand_state = TLS_ST_SR_CHANGE;
                return 1;
            }
        } else {
            if (mt == SSL3_MT_CERTIFICATE_VERIFY) {
                st->hand_state = TLS_ST_SR_CERT_VRFY;
                return 1;
            }
        }
        break;

    case TLS_ST_SR_CERT_VRFY:
        if (mt == SSL3_MT_CHANGE_CIPHER_SPEC) {
            st->hand_state = TLS_ST_SR_CHANGE;
            return 1;
        }
        break;

    case TLS_ST_SR_CHANGE:
#ifndef OPENSSL_NO_NEXTPROTONEG
        if (s->s3.npn_seen) {
            if (mt == SSL3_MT_NEXT_PROTO) {
                st->hand_state = TLS_ST_SR_NEXT_PROTO;
                return 1;
            }
        } else {
#endif
            if (mt == SSL3_MT_FINISHED) {
                st->hand_state = TLS_ST_SR_FINISHED;
                return 1;
            }
#ifndef OPENSSL_NO_NEXTPROTONEG
        }
#endif
        break;

#ifndef OPENSSL_NO_NEXTPROTONEG
    case TLS_ST_SR_NEXT_PROTO:
        if (mt == SSL3_MT_FINISHED) {
            st->hand_state = TLS_ST_SR_FINISHED;
            return 1;
        }
        break;
#endif

    case TLS_ST_SW_FINISHED:
        if (mt == SSL3_MT_CHANGE_CIPHER_SPEC) {
            st->hand_state = TLS_ST_SR_CHANGE;
            return 1;
        }
        break;
    }

err:
    /* No valid transition found */
    SSLfatal(s, SSL3_AD_UNEXPECTED_MESSAGE, SSL_R_UNEXPECTED_MESSAGE);
    return 0;
}

/*
 * Should we send a ServerKeyExchange message?
 *
 * Valid return values are:
 *   1: Yes
 *   0: No
 */
static int send_server_key_exchange(SSL_CONNECTION *s)
{
    unsigned long alg_k = s->s3.tmp.new_cipher->algorithm_mkey;

    /*
     * only send a ServerKeyExchange if DH or fortezza but we have a
     * sign only certificate PSK: may send PSK identity hints For
     * ECC ciphersuites, we send a serverKeyExchange message only if
     * the cipher suite is either ECDH-anon or ECDHE. In other cases,
     * the server certificate contains the server's public key for
     * key exchange.
     */
    if (alg_k & (SSL_kDHE | SSL_kECDHE)
    /*
     * PSK: send ServerKeyExchange if PSK identity hint if
     * provided
     */
#ifndef OPENSSL_NO_PSK
        /* Only send SKE if we have identity hint for plain PSK */
        || ((alg_k & (SSL_kPSK | SSL_kRSAPSK))
            && s->cert->psk_identity_hint)
        /* For other PSK always send SKE */
        || (alg_k & (SSL_PSK & (SSL_kDHEPSK | SSL_kECDHEPSK)))
#endif
#ifndef OPENSSL_NO_SRP
        /* SRP: send ServerKeyExchange */
        || (alg_k & SSL_kSRP)
#endif
    ) {
        return 1;
    }

    return 0;
}

/*
 * Used to determine if we should send a CompressedCertificate message
 *
 * Returns the algorithm to use, TLSEXT_comp_cert_none means no compression
 */
static int get_compressed_certificate_alg(SSL_CONNECTION *sc)
{
#ifndef OPENSSL_NO_COMP_ALG
    int *alg = sc->ext.compress_certificate_from_peer;

    if (sc->s3.tmp.cert == NULL)
        return TLSEXT_comp_cert_none;

    for (; *alg != TLSEXT_comp_cert_none; alg++) {
        if (sc->s3.tmp.cert->comp_cert[*alg] != NULL)
            return *alg;
    }
#endif
    return TLSEXT_comp_cert_none;
}

/*
 * Should we send a CertificateRequest message?
 *
 * Valid return values are:
 *   1: Yes
 *   0: No
 */
int send_certificate_request(SSL_CONNECTION *s)
{
    if (
        /* don't request cert unless asked for it: */
        s->verify_mode & SSL_VERIFY_PEER
        /*
         * don't request if post-handshake-only unless doing
         * post-handshake in TLSv1.3:
         */
        && (!SSL_CONNECTION_IS_VERSION13(s)
            || !(s->verify_mode & SSL_VERIFY_POST_HANDSHAKE)
            || s->post_handshake_auth == SSL_PHA_REQUEST_PENDING)
        /*
         * if SSL_VERIFY_CLIENT_ONCE is set, don't request cert
         * a second time:
         */
        && (s->certreqs_sent < 1 || !(s->verify_mode & SSL_VERIFY_CLIENT_ONCE))
        /*
         * never request cert in anonymous ciphersuites (see
         * section "Certificate request" in SSL 3 drafts and in
         * RFC 2246):
         */
        && (!(s->s3.tmp.new_cipher->algorithm_auth & SSL_aNULL)
            /*
             * ... except when the application insists on
             * verification (against the specs, but statem_clnt.c accepts
             * this for SSL 3)
             */
            || (s->verify_mode & SSL_VERIFY_FAIL_IF_NO_PEER_CERT))
        /* don't request certificate for SRP auth */
        && !(s->s3.tmp.new_cipher->algorithm_auth & SSL_aSRP)
        /*
         * With normal PSK Certificates and Certificate Requests
         * are omitted
         */
        && !(s->s3.tmp.new_cipher->algorithm_auth & SSL_aPSK)) {
        return 1;
    }

    return 0;
}

/*
 * Get the OCSP response for the certificate from the chain identified
 * chainidx.
 * If no OCSP response could be found NULL is returned.
 */
OCSP_RESPONSE *ossl_get_ocsp_response(SSL_CONNECTION *s, int chainidx)
{
    OCSP_RESPONSE *resp = NULL;
#ifndef OPENSSL_NO_OCSP
    int i = 0, num = 0;
    unsigned int len;
    X509 *x = NULL;
    STACK_OF(X509) *chain_certs = NULL;
    SSL *ssl = SSL_CONNECTION_GET_SSL(s);
    OCSP_BASICRESP *bs = NULL;
    OCSP_SINGLERESP *sr = NULL;
    OCSP_CERTID *cid = NULL;
    OCSP_CERTID *sr_cert_id = NULL;
    ASN1_OBJECT *cert_id_md_oid;
    char cert_id_md_txt[OSSL_MAX_NAME_SIZE];
    EVP_MD *cert_id_md;
    ASN1_INTEGER *respSerial;
    ASN1_OCTET_STRING *respIssuerNameHash = NULL;
    ASN1_OCTET_STRING *certIssuerNameHash = NULL;
    const X509_NAME *certIssuerName;
    unsigned char md[EVP_MAX_MD_SIZE];
    const ASN1_INTEGER *certSerial;
    SSL_CTX *sctx = SSL_CONNECTION_GET_CTX(s);

    /*
     * In TLSv1.3 the caller gives the index of the certificate for which the
     * status message should be created.
     * Prior to TLSv1.3 the chain index is 0 and the body should contain only
     * the status of the server certificate itself.
     */
    SSL_get0_chain_certs(ssl, &chain_certs);

    /*
     * If the certificate chain was built, get the status message for the
     * requested certificate specified by chainidx.
     * SSL_get0_chain_certs provides certificate chain except the server cert.
     *
     * if chainidx = 0 the server certificate is requested
     * if chainidx > 0 an intermediate certificate is requested
     */
    if (chainidx == 0)
        x = SSL_get_certificate(ssl);
    else
        x = sk_X509_value(chain_certs, chainidx - 1);
    if (x == NULL)
        return NULL;

    /* for a selfsigned certificate there will be no OCSP response */
    if (X509_self_signed(x, 0))
        return NULL;

    if ((resp = sk_OCSP_RESPONSE_value(s->ext.ocsp.resp_ex, chainidx)) != NULL) {
        /*
         * Find the corresponding single OCSP response by comparing the current
         * certificate's serial number, and the hash of the current certificate's
         * issuer name, to the serial number and issuer name hash in each OCSP
         * response received.
         */
        if (OCSP_response_status(resp) == OCSP_RESPONSE_STATUS_SUCCESSFUL) {
            /*
             * Set a mark for the error queue here to be able to ignore errors
             * happening because of test cases.
             */
            ERR_set_mark();
            bs = OCSP_response_get1_basic(resp);
            if (bs != NULL && (sr = OCSP_resp_get0(bs, 0)) != NULL) {
                /* use the first single response to get the algorithm used */
                cid = (OCSP_CERTID *)OCSP_SINGLERESP_get0_id(sr);

                /* determine the md algorithm which was used to create cert id */
                OCSP_id_get0_info(&respIssuerNameHash, &cert_id_md_oid, NULL, &respSerial, cid);
                if (cert_id_md_oid != NULL) {
                    OBJ_obj2txt(cert_id_md_txt, sizeof(cert_id_md_txt), cert_id_md_oid, 0);
                    cert_id_md = EVP_MD_fetch(sctx->libctx, cert_id_md_txt, sctx->propq);
                } else {
                    cert_id_md = EVP_MD_fetch(sctx->libctx, SN_sha1, sctx->propq);
                }

                if (cert_id_md == NULL) {
                    OCSP_BASICRESP_free(bs);
                    ERR_clear_last_mark();
                    return NULL;
                }

                /* get serial number and issuer name hash of the certificate from the chain */
                certSerial = X509_get0_serialNumber(x);
                certIssuerName = X509_get_issuer_name(x);
                certIssuerNameHash = ASN1_OCTET_STRING_new();
                if (!X509_NAME_digest(certIssuerName, cert_id_md, md, &len) || !(ASN1_OCTET_STRING_set(certIssuerNameHash, md, len))) {
                    ASN1_OCTET_STRING_free(certIssuerNameHash);
                    OCSP_BASICRESP_free(bs);
                    EVP_MD_free(cert_id_md);
                    ERR_clear_last_mark();
                    return NULL;
                }

                num = OCSP_resp_count(bs);
                for (i = 0; i < num; i++) {
                    sr = OCSP_resp_get0(bs, i);

                    /*
                     * get the CertID from the OCSP response to compare it with the information
                     * from the certificate
                     */
                    sr_cert_id = (OCSP_CERTID *)OCSP_SINGLERESP_get0_id(sr);

                    OCSP_id_get0_info(&respIssuerNameHash, NULL, NULL, &respSerial, sr_cert_id);

                    if (!ASN1_INTEGER_cmp(certSerial, respSerial) && !ASN1_OCTET_STRING_cmp(certIssuerNameHash, respIssuerNameHash))
                        break;
                }

                ASN1_OCTET_STRING_free(certIssuerNameHash);
                OCSP_BASICRESP_free(bs);
                EVP_MD_free(cert_id_md);

                /*
                 * if we did not find the right single response we return NULL here
                 */
                if (i == num)
                    resp = NULL;
            } else {
                OCSP_BASICRESP_free(bs);
            }

            /*
             * in a test case a response without a basic response is used the error set
             * could be ignored here
             */
            ERR_pop_to_mark();
        }
    }
#endif

    return resp;
}

static int do_compressed_cert(SSL_CONNECTION *sc)
{
    /* If we negotiated RPK, we won't attempt to compress it */
    return sc->ext.server_cert_type == TLSEXT_cert_type_x509
        && get_compressed_certificate_alg(sc) != TLSEXT_comp_cert_none;
}

/*
 * ossl_statem_server13_write_transition() works out what handshake state to
 * move to next when a TLSv1.3 server is writing messages to be sent to the
 * client.
 */
static WRITE_TRAN ossl_statem_server13_write_transition(SSL_CONNECTION *s)
{
    OSSL_HANDSHAKE_STATE next_state;
    OSSL_STATEM *st = &s->statem;

    if (st->ack_for_retransmit && st->hand_state != TLS_ST_SW_ACK) {
        st->deferred_ack_state = st->hand_state;
        st->hand_state = TLS_ST_SW_ACK;
        return WRITE_TRAN_CONTINUE;
    }

    /*
     * No case for TLS_ST_BEFORE, because at that stage we have not negotiated
     * TLSv1.3 yet, so that is handled by ossl_statem_server_write_transition()
     */

    switch (st->hand_state) {
    default:
        /* Shouldn't happen */
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return WRITE_TRAN_ERROR;

    case TLS_ST_OK:
        if (s->key_update != SSL_KEY_UPDATE_NONE) {
            st->hand_state = TLS_ST_SW_KEY_UPDATE;
            return WRITE_TRAN_CONTINUE;
        }
        if (s->post_handshake_auth == SSL_PHA_REQUEST_PENDING) {
            st->hand_state = TLS_ST_SW_CERT_REQ;
            return WRITE_TRAN_CONTINUE;
        }
        if (s->ext.extra_tickets_expected > 0) {
            st->hand_state = TLS_ST_SW_SESSION_TICKET;
            return WRITE_TRAN_CONTINUE;
        }
        /* Try to read from the client instead */
        return WRITE_TRAN_FINISHED;

    case TLS_ST_SR_CLNT_HELLO:
        st->hand_state = TLS_ST_SW_SRVR_HELLO;
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_SRVR_HELLO:
        if (SSL_CONNECTION_MIDDLEBOX_IS_ENABLED(s)
            && s->hello_retry_request != SSL_HRR_COMPLETE)
            st->hand_state = TLS_ST_SW_CHANGE;
        else if (s->hello_retry_request == SSL_HRR_PENDING)
            st->hand_state = TLS_ST_EARLY_DATA;
        else
            st->hand_state = TLS_ST_SW_ENCRYPTED_EXTENSIONS;
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_CHANGE:
        if (s->hello_retry_request == SSL_HRR_PENDING)
            st->hand_state = TLS_ST_EARLY_DATA;
        else
            st->hand_state = TLS_ST_SW_ENCRYPTED_EXTENSIONS;
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_ENCRYPTED_EXTENSIONS:
        if (s->hit)
            st->hand_state = TLS_ST_SW_FINISHED;
        else if (send_certificate_request(s))
            st->hand_state = TLS_ST_SW_CERT_REQ;
        else if (do_compressed_cert(s))
            st->hand_state = TLS_ST_SW_COMP_CERT;
        else
            st->hand_state = TLS_ST_SW_CERT;

        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_CERT_REQ:
        if (s->post_handshake_auth == SSL_PHA_REQUEST_PENDING) {
            s->post_handshake_auth = SSL_PHA_REQUESTED;
            st->hand_state = TLS_ST_OK;
        } else if (do_compressed_cert(s)) {
            st->hand_state = TLS_ST_SW_COMP_CERT;
        } else {
            st->hand_state = TLS_ST_SW_CERT;
        }
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_COMP_CERT:
    case TLS_ST_SW_CERT:
        st->hand_state = TLS_ST_SW_CERT_VRFY;
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_CERT_VRFY:
        st->hand_state = TLS_ST_SW_FINISHED;
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_FINISHED:
        st->hand_state = TLS_ST_EARLY_DATA;
        s->ts_msg_write = ossl_time_now();
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_EARLY_DATA:
        return WRITE_TRAN_FINISHED;

    case TLS_ST_SR_FINISHED:
        s->ts_msg_read = ossl_time_now();
        /*
         * Technically we have finished the handshake at this point, but we're
         * going to remain "in_init" for now and write out any session tickets
         * immediately.
         */
        if (s->post_handshake_auth == SSL_PHA_REQUESTED) {
            s->post_handshake_auth = SSL_PHA_EXT_RECEIVED;
        } else if (!s->ext.ticket_expected) {
            /*
             * If we're not going to renew the ticket then we just finish the
             * handshake at this point.
             */
            if (SSL_CONNECTION_IS_DTLS13(s)) {
                st->deferred_ack_state = TLS_ST_OK;
                st->hand_state = TLS_ST_SW_ACK;
            } else {
                st->hand_state = TLS_ST_OK;
            }

            return WRITE_TRAN_CONTINUE;
        }
        /*
         * Do not issue TLS 1.3 session tickets if the server has explicitly
         * disabled them via SSL_OP_NO_TICKET and also disabled the session
         * cache with SSL_SESS_CACHE_OFF. Together, these settings clearly
         * indicate an intent to suppress session resumption; sending
         * NewSessionTicket messages in this case would be wasteful and
         * misleading.
         *
         * From the server’s perspective, a client that does not advertise
         * psk_key_exchange_modes in TLS 1.3, or that sends it with RFC 9149
         * parameters such as new_session_count = 0 or resumption_count = 0, is
         * effectively signaling no interest in session tickets or resumption.
         *
         * RFC 9846 section 4.3.9: Servers MUST NOT select a key exchange mode
         * that is not listed by the client. This extension also restricts the
         * modes for use with PSK resumption. Servers SHOULD NOT send
         * NewSessionTicket with tickets that are not compatible with the
         * advertised modes; however, if a server does so, the impact will just
         * be that the client's attempts at resumption fail.
         *
         * Note: Although RFC 9149 allows clients to signal no interest in
         * session tickets or resumption (e.g. new_session_count = 0 or
         * resumption_count = 0), this implementation does not currently
         * interpret or enforce those parameters.
         *
         * Also skip issuance when SSL_VERIFY_PEER is set with no sid_ctx
         * configured: any ticket minted here would be rejected by
         * ssl_get_prev_session() in that configuration.
         */
        if (s->num_tickets <= s->sent_tickets
            || ((s->options & SSL_OP_NO_TICKET) != 0
                && (SSL_CONNECTION_GET_CTX(s)->session_cache_mode & SSL_SESS_CACHE_SERVER)
                    == 0)
            || s->ext.psk_kex_mode == TLSEXT_KEX_MODE_FLAG_NONE
            || ((s->verify_mode & SSL_VERIFY_PEER) != 0 && s->sid_ctx_length == 0))
            next_state = TLS_ST_OK;
        else
            next_state = TLS_ST_SW_SESSION_TICKET;

        if (SSL_CONNECTION_IS_DTLS13(s)) {
            st->deferred_ack_state = next_state;
            st->hand_state = TLS_ST_SW_ACK;
        } else {
            st->hand_state = next_state;
        }
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SR_KEY_UPDATE:
        if (SSL_CONNECTION_IS_DTLS13(s)) {
            st->deferred_ack_state = TLS_ST_OK;
            st->hand_state = TLS_ST_SW_ACK;
            return WRITE_TRAN_CONTINUE;
        }
        /* Fall through */
    case TLS_ST_SW_KEY_UPDATE:
        if (SSL_CONNECTION_IS_DTLS13(s))
            /* We wait for ACK */
            return WRITE_TRAN_FINISHED;
        else
            st->hand_state = TLS_ST_OK;
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_SESSION_TICKET:
        /* In a resumption we only ever send a maximum of one new ticket.
         * Following an initial handshake we send the number of tickets we have
         * been configured for.
         */
        if ((SSL_IS_FIRST_HANDSHAKE(s) || s->ext.extra_tickets_expected <= 0)
            && (s->hit || s->num_tickets <= s->sent_tickets)) {
            /* We've written enough tickets out. */
            st->hand_state = TLS_ST_OK;
        }
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SR_ACK:
        if (SSL_CONNECTION_IS_DTLS13(s)
            && dtls_any_sent_messages_are_missing_acknowledge(s)) {
            /* We wait for ACK */
            return WRITE_TRAN_FINISHED;
        }
        st->hand_state = TLS_ST_OK;
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_ACK:
        st->hand_state = st->deferred_ack_state;
        if (st->ack_for_retransmit) {
            st->ack_for_retransmit = 0;
            return WRITE_TRAN_FINISHED;
        }

        return WRITE_TRAN_CONTINUE;
    }
}

/*
 * ossl_statem_server_write_transition() works out what handshake state to move
 * to next when the server is writing messages to be sent to the client.
 */
WRITE_TRAN ossl_statem_server_write_transition(SSL_CONNECTION *s)
{
    OSSL_STATEM *st = &s->statem;

    /*
     * Note that before the ClientHello we don't know what version we are going
     * to negotiate yet, so we don't take this branch until later
     */

    if (SSL_CONNECTION_IS_VERSION13(s))
        return ossl_statem_server13_write_transition(s);

    switch (st->hand_state) {
    default:
        /* Shouldn't happen */
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return WRITE_TRAN_ERROR;

    case TLS_ST_OK:
        if (st->request_state == TLS_ST_SW_HELLO_REQ) {
            /* We must be trying to renegotiate */
            st->hand_state = TLS_ST_SW_HELLO_REQ;
            st->request_state = TLS_ST_BEFORE;
            return WRITE_TRAN_CONTINUE;
        }
        /* Must be an incoming ClientHello */
        if (!tls_setup_handshake(s)) {
            /* SSLfatal() already called */
            return WRITE_TRAN_ERROR;
        }
        /* Fall through */

    case TLS_ST_BEFORE:
        /* Just go straight to trying to read from the client */
        return WRITE_TRAN_FINISHED;

    case TLS_ST_SW_HELLO_REQ:
        st->hand_state = TLS_ST_OK;
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SR_CLNT_HELLO:
        if (SSL_CONNECTION_IS_DTLS(s) && !SSL_CONNECTION_IS_DTLS13(s) && !s->d1->cookie_verified
            && (SSL_get_options(SSL_CONNECTION_GET_SSL(s)) & SSL_OP_COOKIE_EXCHANGE)) {
            st->hand_state = DTLS_ST_SW_HELLO_VERIFY_REQUEST;
        } else if (s->renegotiate == 0 && !SSL_IS_FIRST_HANDSHAKE(s)) {
            /* We must have rejected the renegotiation */
            st->hand_state = TLS_ST_OK;
            return WRITE_TRAN_CONTINUE;
        } else {
            st->hand_state = TLS_ST_SW_SRVR_HELLO;
        }
        return WRITE_TRAN_CONTINUE;

    case DTLS_ST_SW_HELLO_VERIFY_REQUEST:
        return WRITE_TRAN_FINISHED;

    case TLS_ST_SW_SRVR_HELLO:
        if (s->hit) {
            if (s->ext.ticket_expected)
                st->hand_state = TLS_ST_SW_SESSION_TICKET;
            else
                st->hand_state = TLS_ST_SW_CHANGE;
        } else {
            /* Check if it is anon DH or anon ECDH, */
            /* normal PSK or SRP */
            if (!(s->s3.tmp.new_cipher->algorithm_auth & (SSL_aNULL | SSL_aSRP | SSL_aPSK))) {
                st->hand_state = TLS_ST_SW_CERT;
            } else if (send_server_key_exchange(s)) {
                st->hand_state = TLS_ST_SW_KEY_EXCH;
            } else if (send_certificate_request(s)) {
                st->hand_state = TLS_ST_SW_CERT_REQ;
            } else {
                st->hand_state = TLS_ST_SW_SRVR_DONE;
            }
        }
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_CERT:
        if (s->ext.status_expected) {
            st->hand_state = TLS_ST_SW_CERT_STATUS;
            return WRITE_TRAN_CONTINUE;
        }
        /* Fall through */

    case TLS_ST_SW_CERT_STATUS:
        if (send_server_key_exchange(s)) {
            st->hand_state = TLS_ST_SW_KEY_EXCH;
            return WRITE_TRAN_CONTINUE;
        }
        /* Fall through */

    case TLS_ST_SW_KEY_EXCH:
        if (send_certificate_request(s)) {
            st->hand_state = TLS_ST_SW_CERT_REQ;
            return WRITE_TRAN_CONTINUE;
        }
        /* Fall through */

    case TLS_ST_SW_CERT_REQ:
        st->hand_state = TLS_ST_SW_SRVR_DONE;
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_SRVR_DONE:
        s->ts_msg_write = ossl_time_now();
        return WRITE_TRAN_FINISHED;

    case TLS_ST_SR_FINISHED:
        s->ts_msg_read = ossl_time_now();
        if (s->hit) {
            st->hand_state = TLS_ST_OK;
            return WRITE_TRAN_CONTINUE;
        } else if (s->ext.ticket_expected) {
            st->hand_state = TLS_ST_SW_SESSION_TICKET;
        } else {
            st->hand_state = TLS_ST_SW_CHANGE;
        }
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_SESSION_TICKET:
        st->hand_state = TLS_ST_SW_CHANGE;
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_CHANGE:
        st->hand_state = TLS_ST_SW_FINISHED;
        return WRITE_TRAN_CONTINUE;

    case TLS_ST_SW_FINISHED:
        if (s->hit) {
            return WRITE_TRAN_FINISHED;
        }
        st->hand_state = TLS_ST_OK;
        return WRITE_TRAN_CONTINUE;
    }
}

static int ossl_statem_dtls_server13_use_timer(SSL_CONNECTION *s)
{
    OSSL_STATEM *st = &s->statem;

    switch (st->hand_state) {
    default:
        break;

    case TLS_ST_SW_ACK:
        /* Fall through */

    case TLS_ST_OK:
        return 0;
    }

    return 1;
}

int ossl_statem_dtls_server_use_timer(SSL_CONNECTION *s)
{
    OSSL_STATEM *st = &s->statem;

    if (SSL_CONNECTION_IS_DTLS13(s))
        return ossl_statem_dtls_server13_use_timer(s);

    switch (st->hand_state) {
    default:
        break;

    case TLS_ST_SW_SESSION_TICKET:
        /*
         * We're into the last flight. We don't retransmit the last flight
         * unless we need to, so we don't use the timer
         */
        st->use_timer = 0;
        break;

    case TLS_ST_SW_CHANGE:
        /*
         * We're into the last flight. We don't retransmit the last flight
         * unless we need to, so we don't use the timer. This might have
         * already been set to 0 if we sent a NewSessionTicket message,
         * but we'll set it again here in case we didn't.
         */
        st->use_timer = 0;
        break;

    case DTLS_ST_SW_HELLO_VERIFY_REQUEST:
        /* We don't buffer this message so don't use the timer */
        st->use_timer = 0;
        break;

    case TLS_ST_SW_SRVR_HELLO:
        /*
         * Messages we write from now on should be buffered and
         * retransmitted if necessary, so we need to use the timer now
         */
        st->use_timer = 1;
        break;
    }

    return st->use_timer;
}

/*
 * Perform any pre work that needs to be done prior to sending a message from
 * the server to the client.
 */
WORK_STATE ossl_statem_server_pre_work(SSL_CONNECTION *s, WORK_STATE wst)
{
    OSSL_STATEM *st = &s->statem;
    SSL *ssl = SSL_CONNECTION_GET_SSL(s);

    switch (st->hand_state) {
    default:
        /* No pre work to be done */
        break;

    case TLS_ST_SW_HELLO_REQ:
        /* fall-through */
    case DTLS_ST_SW_HELLO_VERIFY_REQUEST:
        s->shutdown = 0;
        if (SSL_CONNECTION_IS_DTLS(s))
            dtls1_clear_sent_buffer(s, 0);

        break;

    case TLS_ST_SW_SRVR_DONE:
#ifndef OPENSSL_NO_SCTP
        if (SSL_CONNECTION_IS_DTLS(s) && BIO_dgram_is_sctp(SSL_get_wbio(ssl))) {
            /* Calls SSLfatal() as required */
            return dtls_wait_for_dry(s);
        }
#endif
        return WORK_FINISHED_CONTINUE;

    case TLS_ST_SW_SESSION_TICKET:
        if (SSL_CONNECTION_IS_VERSION13(s) && s->sent_tickets == 0
            && s->ext.extra_tickets_expected == 0) {
            /*
             * Actually this is the end of the handshake, but we're going
             * straight into writing the session ticket out. So we finish off
             * the handshake, but keep the various buffers active.
             *
             * Calls SSLfatal as required.
             */
            return tls_finish_handshake(s, wst, 0, 0);
        }
        break;

    case TLS_ST_SW_CHANGE:
        if (SSL_CONNECTION_IS_VERSION13(s))
            break;
        /* Writes to s->session are only safe for initial handshakes */
        if (s->session->cipher == NULL) {
            s->session->cipher = s->s3.tmp.new_cipher;
        } else if (s->session->cipher != s->s3.tmp.new_cipher) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            return WORK_ERROR;
        }
        if (!ssl->method->ssl3_enc->setup_key_block(s)) {
            /* SSLfatal() already called */
            return WORK_ERROR;
        }
        return WORK_FINISHED_CONTINUE;

    case TLS_ST_EARLY_DATA:
        if (s->early_data_state != SSL_EARLY_DATA_ACCEPTING
            && (s->s3.flags & TLS1_FLAGS_STATELESS) == 0)
            return WORK_FINISHED_CONTINUE;

        /*
         * In QUIC with 0-RTT we just carry on when otherwise we would stop
         * to allow the server to read early data
         */
        if (SSL_IS_QUIC_HANDSHAKE(s) && s->ext.early_data == SSL_EARLY_DATA_ACCEPTED
            && s->early_data_state != SSL_EARLY_DATA_FINISHED_READING) {
            s->early_data_state = SSL_EARLY_DATA_FINISHED_READING;
            if (!ssl->method->ssl3_enc->change_cipher_state(s, SSL3_CC_HANDSHAKE | SSL3_CHANGE_CIPHER_SERVER_READ)) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                return WORK_ERROR;
            }
            return WORK_FINISHED_SWAP;
        }
        /* Fall through */

    case TLS_ST_OK:
        /* Calls SSLfatal() as required */
        return tls_finish_handshake(s, wst, 1, 1);
    }

    return WORK_FINISHED_CONTINUE;
}

static ossl_inline int conn_is_closed(void)
{
    switch (get_last_sys_error()) {
#if defined(EPIPE)
    case EPIPE:
        return 1;
#endif
#if defined(ECONNRESET)
    case ECONNRESET:
        return 1;
#endif
#if defined(WSAECONNRESET)
    case WSAECONNRESET:
        return 1;
#endif
    default:
        return 0;
    }
}

/*
 * Perform any work that needs to be done after sending a message from the
 * server to the client.
 */
WORK_STATE ossl_statem_server_post_work(SSL_CONNECTION *s, WORK_STATE wst)
{
    OSSL_STATEM *st = &s->statem;
    SSL *ssl = SSL_CONNECTION_GET_SSL(s);

    s->init_num = 0;

    switch (st->hand_state) {
    default:
        /* No post work to be done */
        break;

    case TLS_ST_SW_HELLO_REQ:
        if (statem_flush(s) != 1)
            return WORK_MORE_A;
        if (!ssl3_init_finished_mac(s)) {
            /* SSLfatal() already called */
            return WORK_ERROR;
        }
        break;

    case DTLS_ST_SW_HELLO_VERIFY_REQUEST:
        if (statem_flush(s) != 1)
            return WORK_MORE_A;
        /* HelloVerifyRequest resets Finished MAC */
        if (s->version != DTLS1_BAD_VER && !ssl3_init_finished_mac(s)) {
            /* SSLfatal() already called */
            return WORK_ERROR;
        }
        /*
         * The next message should be another ClientHello which we need to
         * treat like it was the first packet
         */
        s->first_packet = 1;
        break;

    case TLS_ST_SW_SRVR_HELLO:
        if (SSL_CONNECTION_IS_VERSION13(s)
            && s->hello_retry_request == SSL_HRR_PENDING) {
            if (!SSL_CONNECTION_MIDDLEBOX_IS_ENABLED(s)
                && statem_flush(s) != 1)
                return WORK_MORE_A;
            break;
        }
#ifndef OPENSSL_NO_SCTP
        /*
         * Before exporting the SCTP auth key we check if DTLSv1.3 has been negotiated
         * which is not supported.
         * Refer to draft-tuexen-tsvwg-rfc6083-bis-04 for more info.
         */
        if (SSL_CONNECTION_IS_DTLS(s) && !SSL_CONNECTION_IS_DTLS13(s) && s->hit) {
            unsigned char sctpauthkey[64];
            char labelbuffer[sizeof(DTLS1_SCTP_AUTH_LABEL)];
            size_t labellen;

            /*
             * Add new shared key for SCTP-Auth, will be ignored if no
             * SCTP used.
             */
            memcpy(labelbuffer, DTLS1_SCTP_AUTH_LABEL,
                sizeof(DTLS1_SCTP_AUTH_LABEL));

            /* Don't include the terminating zero. */
            labellen = sizeof(labelbuffer) - 1;
            if (s->mode & SSL_MODE_DTLS_SCTP_LABEL_LENGTH_BUG)
                labellen += 1;

            if (SSL_export_keying_material(ssl, sctpauthkey,
                    sizeof(sctpauthkey), labelbuffer,
                    labellen, NULL, 0,
                    0)
                <= 0) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                return WORK_ERROR;
            }

            BIO_ctrl(SSL_get_wbio(ssl), BIO_CTRL_DGRAM_SCTP_ADD_AUTH_KEY,
                sizeof(sctpauthkey), sctpauthkey);
        }
#endif
        if (!SSL_CONNECTION_IS_VERSION13(s)
            || (SSL_CONNECTION_MIDDLEBOX_IS_ENABLED(s)
                && s->hello_retry_request != SSL_HRR_COMPLETE))
            break;
        /* Fall through */

    case TLS_ST_SW_CHANGE:
        if (s->hello_retry_request == SSL_HRR_PENDING) {
            if (!statem_flush(s))
                return WORK_MORE_A;
            break;
        }

        if (SSL_CONNECTION_IS_VERSION13(s)) {
            if (!ssl->method->ssl3_enc->setup_key_block(s)
                || !tls13_store_handshake_traffic_hash(s)
                || !ssl->method->ssl3_enc->change_cipher_state(s,
                    SSL3_CC_HANDSHAKE | SSL3_CHANGE_CIPHER_SERVER_WRITE)) {
                /* SSLfatal() already called */
                return WORK_ERROR;
            }

            if (SSL_CONNECTION_IS_DTLS13(s)) {
                dtls13_hellos_done(s);
            } else if (s->ext.early_data != SSL_EARLY_DATA_ACCEPTED
                && !ssl->method->ssl3_enc->change_cipher_state(s,
                    SSL3_CC_HANDSHAKE | SSL3_CHANGE_CIPHER_SERVER_READ)) {
                /* SSLfatal() already called */
                return WORK_ERROR;
            }
            /*
             * We don't yet know whether the next record we are going to receive
             * is an unencrypted alert, an encrypted alert, or an encrypted
             * handshake message. We temporarily tolerate unencrypted alerts.
             */
            if (s->rlayer.rrlmethod->set_plain_alerts != NULL)
                s->rlayer.rrlmethod->set_plain_alerts(s->rlayer.rrl, 1);
            break;
        }

#ifndef OPENSSL_NO_SCTP
        if (SSL_CONNECTION_IS_DTLS(s) && !s->hit) {
            /*
             * Change to new shared key of SCTP-Auth, will be ignored if
             * no SCTP used.
             */
            BIO_ctrl(SSL_get_wbio(ssl), BIO_CTRL_DGRAM_SCTP_NEXT_AUTH_KEY,
                0, NULL);
        }
#endif
        if (!ssl->method->ssl3_enc->change_cipher_state(s,
                SSL3_CHANGE_CIPHER_SERVER_WRITE)) {
            /* SSLfatal() already called */
            return WORK_ERROR;
        }
        break;

    case TLS_ST_SW_SRVR_DONE:
        if (statem_flush(s) != 1)
            return WORK_MORE_A;
        break;

    case TLS_ST_SW_FINISHED:
        if (statem_flush(s) != 1)
            return WORK_MORE_A;
#ifndef OPENSSL_NO_SCTP
        if (SSL_CONNECTION_IS_DTLS(s) && s->hit) {
            /*
             * Change to new shared key of SCTP-Auth, will be ignored if
             * no SCTP used.
             */
            BIO_ctrl(SSL_get_wbio(ssl), BIO_CTRL_DGRAM_SCTP_NEXT_AUTH_KEY,
                0, NULL);
        }
#endif
        if (SSL_CONNECTION_IS_VERSION13(s)) {
            /* (D)TLS 1.3 gets the secret size from the handshake md */
            size_t dummy;
            if (!ssl->method->ssl3_enc->generate_master_secret(s,
                    s->master_secret, s->handshake_secret, 0,
                    &dummy)
                || !tls13_store_server_finished_hash(s)
                || !ssl->method->ssl3_enc->change_cipher_state(s,
                    SSL3_CC_APPLICATION | SSL3_CHANGE_CIPHER_SERVER_WRITE))
                /* SSLfatal() already called */
                return WORK_ERROR;
        }
        break;

    case TLS_ST_SW_CERT_REQ:
        if (s->post_handshake_auth == SSL_PHA_REQUEST_PENDING) {
            if (statem_flush(s) != 1)
                return WORK_MORE_A;
        } else {
            if (!SSL_CONNECTION_IS_VERSION13(s)
                || (s->options & SSL_OP_NO_TX_CERTIFICATE_COMPRESSION) != 0)
                s->ext.compress_certificate_from_peer[0] = TLSEXT_comp_cert_none;
        }
        break;

    case TLS_ST_SW_ENCRYPTED_EXTENSIONS:
        if (!s->hit && !send_certificate_request(s)) {
            if (!SSL_CONNECTION_IS_VERSION13(s)
                || (s->options & SSL_OP_NO_TX_CERTIFICATE_COMPRESSION) != 0)
                s->ext.compress_certificate_from_peer[0] = TLSEXT_comp_cert_none;
        }
        break;

    case TLS_ST_SW_KEY_UPDATE:
        if (statem_flush(s) != 1)
            return WORK_MORE_A;
        if (!tls13_update_key(s, 1)) {
            /* SSLfatal() already called */
            return WORK_ERROR;
        }
        break;

    case TLS_ST_SW_SESSION_TICKET:
        clear_sys_error();
        if (SSL_CONNECTION_IS_VERSION13(s) && statem_flush(s) != 1) {
            if (SSL_get_error(ssl, 0) == SSL_ERROR_SYSCALL
                && conn_is_closed()) {
                /*
                 * We ignore connection closed errors in TLSv1.3 when sending a
                 * NewSessionTicket and behave as if we were successful. This is
                 * so that we are still able to read data sent to us by a client
                 * that closes soon after the end of the handshake without
                 * waiting to read our post-handshake NewSessionTickets.
                 */
                s->rwstate = SSL_NOTHING;
                break;
            }

            return WORK_MORE_A;
        }
        ERR_clear_last_mark();
        break;

    case TLS_ST_SW_ACK:
        if (statem_flush(s) != 1)
            return WORK_MORE_A;
        break;
    }

    return WORK_FINISHED_CONTINUE;
}

/*
 * Get the message construction function and message type for sending from the
 * server
 *
 * Valid return values are:
 *   1: Success
 *   0: Error
 */
int ossl_statem_server_construct_message(SSL_CONNECTION *s,
    confunc_f *confunc, int *mt)
{
    OSSL_STATEM *st = &s->statem;

    switch (st->hand_state) {
    default:
        /* Shouldn't happen */
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_BAD_HANDSHAKE_STATE);
        return 0;

    case TLS_ST_SW_CHANGE:
        if (SSL_CONNECTION_IS_DTLS(s))
            *confunc = dtls_construct_change_cipher_spec;
        else
            *confunc = tls_construct_change_cipher_spec;
        *mt = SSL3_MT_CHANGE_CIPHER_SPEC;
        break;

    case DTLS_ST_SW_HELLO_VERIFY_REQUEST:
        *confunc = dtls_construct_hello_verify_request;
        *mt = DTLS1_MT_HELLO_VERIFY_REQUEST;
        break;

    case TLS_ST_SW_HELLO_REQ:
        /* No construction function needed */
        *confunc = NULL;
        *mt = SSL3_MT_HELLO_REQUEST;
        break;

    case TLS_ST_SW_SRVR_HELLO:
        *confunc = tls_construct_server_hello;
        *mt = SSL3_MT_SERVER_HELLO;
        break;

    case TLS_ST_SW_CERT:
        *confunc = tls_construct_server_certificate;
        *mt = SSL3_MT_CERTIFICATE;
        break;

#ifndef OPENSSL_NO_COMP_ALG
    case TLS_ST_SW_COMP_CERT:
        *confunc = tls_construct_server_compressed_certificate;
        *mt = SSL3_MT_COMPRESSED_CERTIFICATE;
        break;
#endif

    case TLS_ST_SW_CERT_VRFY:
        *confunc = tls_construct_cert_verify;
        *mt = SSL3_MT_CERTIFICATE_VERIFY;
        break;

    case TLS_ST_SW_KEY_EXCH:
        *confunc = tls_construct_server_key_exchange;
        *mt = SSL3_MT_SERVER_KEY_EXCHANGE;
        break;

    case TLS_ST_SW_CERT_REQ:
        *confunc = tls_construct_certificate_request;
        *mt = SSL3_MT_CERTIFICATE_REQUEST;
        break;

    case TLS_ST_SW_SRVR_DONE:
        *confunc = tls_construct_server_done;
        *mt = SSL3_MT_SERVER_DONE;
        break;

    case TLS_ST_SW_SESSION_TICKET:
        *confunc = tls_construct_new_session_ticket;
        *mt = SSL3_MT_NEWSESSION_TICKET;
        break;

    case TLS_ST_SW_CERT_STATUS:
        *confunc = tls_construct_cert_status;
        *mt = SSL3_MT_CERTIFICATE_STATUS;
        break;

    case TLS_ST_SW_FINISHED:
        *confunc = tls_construct_finished;
        *mt = SSL3_MT_FINISHED;
        break;

    case TLS_ST_EARLY_DATA:
        *confunc = NULL;
        *mt = SSL3_MT_DUMMY;
        break;

    case TLS_ST_SW_ENCRYPTED_EXTENSIONS:
        *confunc = tls_construct_encrypted_extensions;
        *mt = SSL3_MT_ENCRYPTED_EXTENSIONS;
        break;

    case TLS_ST_SW_KEY_UPDATE:
        *confunc = tls_construct_key_update;
        *mt = SSL3_MT_KEY_UPDATE;
        break;

    case TLS_ST_SW_ACK:
        *confunc = dtls_construct_ack;
        *mt = DTLS13_MT_ACK;
        break;
    }

    return 1;
}

/*
 * Maximum size (excluding the Handshake header) of a ClientHello message,
 * calculated as follows:
 *
 *  2 + # client_version
 *  32 + # only valid length for random
 *  1 + # length of session_id
 *  32 + # maximum size for session_id
 *  2 + # length of cipher suites
 *  2^16-2 + # maximum length of cipher suites array
 *  1 + # length of compression_methods
 *  2^8-1 + # maximum length of compression methods
 *  2 + # length of extensions
 *  2^16-1 # maximum length of extensions
 */
#define CLIENT_HELLO_MAX_LENGTH 131396

#define CLIENT_KEY_EXCH_MAX_LENGTH 2048
#define NEXT_PROTO_MAX_LENGTH 514

/*
 * Returns the maximum allowed length for the current message that we are
 * reading. Excludes the message header.
 */
size_t ossl_statem_server_max_message_size(SSL_CONNECTION *s)
{
    OSSL_STATEM *st = &s->statem;

    switch (st->hand_state) {
    default:
        /* Shouldn't happen */
        return 0;

    case TLS_ST_SR_CLNT_HELLO:
        return CLIENT_HELLO_MAX_LENGTH;

    case TLS_ST_SR_END_OF_EARLY_DATA:
        return END_OF_EARLY_DATA_MAX_LENGTH;

    case TLS_ST_SR_COMP_CERT:
    case TLS_ST_SR_CERT:
        return s->max_cert_list;

    case TLS_ST_SR_KEY_EXCH:
        return CLIENT_KEY_EXCH_MAX_LENGTH;

    case TLS_ST_SR_CERT_VRFY:
        return CERTIFICATE_VERIFY_MAX_LENGTH;

#ifndef OPENSSL_NO_NEXTPROTONEG
    case TLS_ST_SR_NEXT_PROTO:
        return NEXT_PROTO_MAX_LENGTH;
#endif

    case TLS_ST_SR_CHANGE:
        return CCS_MAX_LENGTH;

    case TLS_ST_SR_FINISHED:
        return FINISHED_MAX_LENGTH;

    case TLS_ST_SR_KEY_UPDATE:
        return KEY_UPDATE_MAX_LENGTH;

    case TLS_ST_SR_ACK:
        return ACK_MAX_LENGTH;
    }
}

/*
 * Process a message that the server has received from the client.
 */
MSG_PROCESS_RETURN ossl_statem_server_process_message(SSL_CONNECTION *s,
    PACKET *pkt)
{
    OSSL_STATEM *st = &s->statem;

    switch (st->hand_state) {
    default:
        /* Shouldn't happen */
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return MSG_PROCESS_ERROR;

    case TLS_ST_SR_CLNT_HELLO:
        return tls_process_client_hello(s, pkt);

    case TLS_ST_SR_END_OF_EARLY_DATA:
        return tls_process_end_of_early_data(s, pkt);

    case TLS_ST_SR_CERT:
        return tls_process_client_certificate(s, pkt);

#ifndef OPENSSL_NO_COMP_ALG
    case TLS_ST_SR_COMP_CERT:
        return tls_process_client_compressed_certificate(s, pkt);
#endif

    case TLS_ST_SR_KEY_EXCH:
        return tls_process_client_key_exchange(s, pkt);

    case TLS_ST_SR_CERT_VRFY:
        return tls_process_cert_verify(s, pkt);

#ifndef OPENSSL_NO_NEXTPROTONEG
    case TLS_ST_SR_NEXT_PROTO:
        return tls_process_next_proto(s, pkt);
#endif

    case TLS_ST_SR_CHANGE:
        return tls_process_change_cipher_spec(s, pkt);

    case TLS_ST_SR_FINISHED:
        return tls_process_finished(s, pkt);

    case TLS_ST_SR_KEY_UPDATE:
        return tls_process_key_update(s, pkt);

    case TLS_ST_SR_ACK:
        return dtls_process_ack(s, pkt);
    }
}

/*
 * Perform any further processing required following the receipt of a message
 * from the client
 */
WORK_STATE ossl_statem_server_post_process_message(SSL_CONNECTION *s,
    WORK_STATE wst)
{
    OSSL_STATEM *st = &s->statem;

    switch (st->hand_state) {
    default:
        /* Shouldn't happen */
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return WORK_ERROR;

    case TLS_ST_SR_CLNT_HELLO:
        return tls_post_process_client_hello(s, wst);

    case TLS_ST_SR_CERT:
#ifndef OPENSSL_NO_COMP_ALG
    case TLS_ST_SR_COMP_CERT:
#endif
        return tls_post_process_client_certificate(s, wst);

    case TLS_ST_SR_KEY_EXCH:
        return tls_post_process_client_key_exchange(s, wst);
    }
}

#ifndef OPENSSL_NO_SRP
/* Returns 1 on success, 0 for retryable error, -1 for fatal error */
static int ssl_check_srp_ext_ClientHello(SSL_CONNECTION *s)
{
    int ret;
    int al = SSL_AD_UNRECOGNIZED_NAME;

    if ((s->s3.tmp.new_cipher->algorithm_mkey & SSL_kSRP) && (s->srp_ctx.TLS_ext_srp_username_callback != NULL)) {
        if (s->srp_ctx.login == NULL) {
            /*
             * RFC 5054 says SHOULD reject, we do so if There is no srp
             * login name
             */
            SSLfatal(s, SSL_AD_UNKNOWN_PSK_IDENTITY,
                SSL_R_PSK_IDENTITY_NOT_FOUND);
            return -1;
        } else {
            ret = ssl_srp_server_param_with_username_intern(s, &al);
            if (ret < 0)
                return 0;
            if (ret == SSL3_AL_FATAL) {
                SSLfatal(s, al,
                    al == SSL_AD_UNKNOWN_PSK_IDENTITY
                        ? SSL_R_PSK_IDENTITY_NOT_FOUND
                        : SSL_R_CLIENTHELLO_TLSEXT);
                return -1;
            }
        }
    }
    return 1;
}
#endif

int dtls_raw_hello_verify_request(WPACKET *pkt, unsigned char *cookie,
    size_t cookie_len)
{
    /* Always use DTLS 1.0 version: see RFC 6347 */
    if (!WPACKET_put_bytes_u16(pkt, DTLS1_VERSION)
        || !WPACKET_sub_memcpy_u8(pkt, cookie, cookie_len))
        return 0;

    return 1;
}

CON_FUNC_RETURN dtls_construct_hello_verify_request(SSL_CONNECTION *s,
    WPACKET *pkt)
{
    unsigned int cookie_leni = 0;
    SSL_CTX *sctx = SSL_CONNECTION_GET_CTX(s);
    SSL *ussl = SSL_CONNECTION_GET_USER_SSL(s);
    int cb_ret = 0;

#if !defined(OPENSSL_NO_DTLS)
    DTLS_LISTENER *dl = (DTLS_LISTENER *)s->d1->listener;

    if (dl != NULL && dl->require_hvr_cookie && sctx->app_gen_cookie_cb == NULL) {
        cb_ret = ossl_dtls_listener_gen_cookie_cb(ussl, s->d1->cookie, &cookie_leni);
    } else
#endif
        if (sctx->app_gen_cookie_cb != NULL) {
        cb_ret = sctx->app_gen_cookie_cb(ussl, s->d1->cookie, &cookie_leni);
    }

    if (cb_ret == 0 || cookie_leni > sizeof(s->d1->cookie)) {
        SSLfatal(s, SSL_AD_NO_ALERT, SSL_R_COOKIE_GEN_CALLBACK_FAILURE);
        return CON_FUNC_ERROR;
    }
    s->d1->cookie_len = cookie_leni;

    if (!dtls_raw_hello_verify_request(pkt, s->d1->cookie,
            s->d1->cookie_len)) {
        SSLfatal(s, SSL_AD_NO_ALERT, ERR_R_INTERNAL_ERROR);
        return CON_FUNC_ERROR;
    }

    /*
     * Server must recover the downgrade sentinel in case it sends a
     * HelloVerifyRequest.
     */
    s->d1->hello_verify_request = SSL_HVR_SENT;

    return CON_FUNC_SUCCESS;
}

/*-
 * ssl_check_for_safari attempts to fingerprint Safari using OS X
 * SecureTransport using the TLS extension block in |hello|.
 * Safari, since 10.6, sends exactly these extensions, in this order:
 *   SNI,
 *   elliptic_curves
 *   ec_point_formats
 *   signature_algorithms (for TLSv1.2 only)
 *
 * We wish to fingerprint Safari because they broke ECDHE-ECDSA support in 10.8,
 * but they advertise support. So enabling ECDHE-ECDSA ciphers breaks them.
 * Sadly we cannot differentiate 10.6, 10.7 and 10.8.4 (which work), from
 * 10.8..10.8.3 (which don't work).
 */
static void ssl_check_for_safari(SSL_CONNECTION *s,
    const CLIENTHELLO_MSG *hello)
{
    static const unsigned char kSafariExtensionsBlock[] = {
        0x00,
        0x0a, /* elliptic_curves extension */
        0x00,
        0x08, /* 8 bytes */
        0x00,
        0x06, /* 6 bytes of curve ids */
        0x00,
        0x17, /* P-256 */
        0x00,
        0x18, /* P-384 */
        0x00,
        0x19, /* P-521 */

        0x00,
        0x0b, /* ec_point_formats */
        0x00,
        0x02, /* 2 bytes */
        0x01, /* 1 point format */
        0x00, /* uncompressed */
        /* The following is only present in TLS 1.2 */
        0x00,
        0x0d, /* signature_algorithms */
        0x00,
        0x0c, /* 12 bytes */
        0x00,
        0x0a, /* 10 bytes */
        0x05,
        0x01, /* SHA-384/RSA */
        0x04,
        0x01, /* SHA-256/RSA */
        0x02,
        0x01, /* SHA-1/RSA */
        0x04,
        0x03, /* SHA-256/ECDSA */
        0x02,
        0x03, /* SHA-1/ECDSA */
    };
    /* Length of the common prefix (first two extensions). */
    static const size_t kSafariCommonExtensionsLength = 18;
    unsigned int type;
    PACKET sni, tmppkt;
    size_t ext_len;

    tmppkt = hello->extensions;

    if (!PACKET_forward(&tmppkt, 2)
        || !PACKET_get_net_2(&tmppkt, &type)
        || !PACKET_get_length_prefixed_2(&tmppkt, &sni)) {
        return;
    }

    if (type != TLSEXT_TYPE_server_name)
        return;

    ext_len = TLS1_get_client_version(
                  SSL_CONNECTION_GET_SSL(s))
            >= TLS1_2_VERSION
        ? sizeof(kSafariExtensionsBlock)
        : kSafariCommonExtensionsLength;

    s->s3.is_probably_safari = PACKET_equal(&tmppkt, kSafariExtensionsBlock,
        ext_len);
}

#define RENEG_OPTIONS_OK(options)             \
    ((options & SSL_OP_NO_RENEGOTIATION) == 0 \
        && (options & SSL_OP_ALLOW_CLIENT_RENEGOTIATION) != 0)

MSG_PROCESS_RETURN tls_process_client_hello(SSL_CONNECTION *s, PACKET *pkt)
{
    /* |cookie| will only be initialized for DTLS. */
    PACKET session_id, compression, extensions, cookie;
    CLIENTHELLO_MSG *clienthello = NULL;

#ifndef OPENSSL_NO_ECH
    /*
     * For a split-mode backend we want to have a way to point at the CH octets
     * for the accept-confirmation calculation. The split-mode backend does not
     * need any ECH secrets, but it does need to see the inner CH and be the TLS
     * endpoint with which the ECH encrypting client sets up the TLS session.
     * The split-mode backend however does need to do an ECH confirm calculation
     * so we need to tee that up. The result of that calculation will be put in
     * the ServerHello.random (or ECH extension if HRR) to signal to the client
     * that ECH "worked."
     */
    if (s->server && PACKET_remaining(pkt) != 0) {
        int rv = 0, innerflag = OSSL_ECH_UNKNOWN_CH_TYPE;
        size_t startofsessid = 0, startofexts = 0, echoffset = 0;
        size_t outersnioffset = 0; /* offset to SNI in outer */
        uint16_t echtype = OSSL_ECH_type_unknown; /* type of ECH seen */
        const unsigned char *pbuf = NULL;

        /* reset needed in case of HRR */
        s->ext.ech.ch_offsets_done = 0;
        rv = ossl_ech_get_ch_offsets(s, pkt, &startofsessid, &startofexts,
            &echoffset, &echtype, &innerflag,
            &outersnioffset);
        if (rv != 1) {
            /* SSLfatal already called */
            goto err;
        }
        if (innerflag == OSSL_ECH_INNER_CH_TYPE) {
            WPACKET inner;

            OSSL_TRACE(TLS, "Got inner ECH so setting backend\n");
            /* For backend, include msg type & 3 octet length */
            s->ext.ech.backend = 1;
            s->ext.ech.attempted_type = TLSEXT_TYPE_ech;
            OPENSSL_free(s->ext.ech.innerch);
            s->ext.ech.innerch_len = PACKET_remaining(pkt);
            if (PACKET_peek_bytes(pkt, &pbuf, s->ext.ech.innerch_len) != 1) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                goto err;
            }
            s->ext.ech.innerch_len += SSL3_HM_HEADER_LENGTH; /* 4 */
            s->ext.ech.innerch = OPENSSL_malloc(s->ext.ech.innerch_len);
            if (s->ext.ech.innerch == NULL) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                goto err;
            }
            if (!WPACKET_init_static_len(&inner, s->ext.ech.innerch,
                    s->ext.ech.innerch_len, 0)) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                goto err;
            }
            if (!WPACKET_put_bytes_u8(&inner, SSL3_MT_CLIENT_HELLO)
                || !WPACKET_put_bytes_u24(&inner, s->ext.ech.innerch_len - SSL3_HM_HEADER_LENGTH)
                || !WPACKET_memcpy(&inner, pbuf, s->ext.ech.innerch_len - SSL3_HM_HEADER_LENGTH)
                || !WPACKET_finish(&inner)) {
                WPACKET_cleanup(&inner);
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                goto err;
            }
            if (ossl_ech_intbuf_add(s, s->ext.ech.innerch,
                    s->ext.ech.innerch_len, 0)
                != 1) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                goto err;
            }
        } else if (s->ext.ech.es != NULL) {
            PACKET newpkt;
            int secondtime = s->ext.ech.success;

            /*
             * if ECH decrypt worked first time (success == 1) then fail
             * if there's no ECH extension at all 2nd time
             */
            if (secondtime == 1 && echoffset == 0) {
                SSLfatal(s, SSL_AD_MISSING_EXTENSION,
                    SSL_R_TLSV13_ALERT_MISSING_EXTENSION);
                goto err;
            }
            if (ossl_ech_early_decrypt(s, pkt, &newpkt) != 1) {
                /* SSLfatal() already called */
                goto err;
            }
            if (s->ext.ech.success == 1) {
                /*
                 * Replace the outer CH with the inner, as long as there's
                 * space, which there better be! (a bug triggered a bigger
                 * inner CH once;-)
                 */
                if (PACKET_remaining(&newpkt) > PACKET_remaining(pkt)) {
                    SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                    goto err;
                }
                *pkt = newpkt;
            } else if (secondtime == 1 && s->ext.ech.success == 0) {
                /* 2nd time decrypt failed */
                SSLfatal(s, SSL_AD_DECRYPT_ERROR, ERR_R_INTERNAL_ERROR);
                goto err;
            }
        }
    }
#endif

    /* Check if this is actually an unexpected renegotiation ClientHello */
    if (s->renegotiate == 0 && !SSL_IS_FIRST_HANDSHAKE(s)) {
        if (!ossl_assert(!SSL_CONNECTION_IS_VERSION13(s))) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }
        if (!RENEG_OPTIONS_OK(s->options)
            || (!s->s3.send_connection_binding
                && (s->options
                       & SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION)
                    == 0)) {
            ssl3_send_alert(s, SSL3_AL_WARNING, SSL_AD_NO_RENEGOTIATION);
            return MSG_PROCESS_FINISHED_READING;
        }
        s->renegotiate = 1;
        s->new_session = 1;
    }

    clienthello = OPENSSL_zalloc(sizeof(*clienthello));
    if (clienthello == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }

    /*
     * First, parse the raw ClientHello data into the CLIENTHELLO_MSG structure.
     */
    PACKET_null_init(&cookie);

    if (!PACKET_get_net_2(pkt, &clienthello->legacy_version)) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_TOO_SHORT);
        goto err;
    }

    if (!PACKET_copy_bytes(pkt, clienthello->random, SSL3_RANDOM_SIZE)
        || !PACKET_get_length_prefixed_1(pkt, &session_id)
        || !PACKET_copy_all(&session_id, clienthello->session_id,
            SSL_MAX_SSL_SESSION_ID_LENGTH,
            &clienthello->session_id_len)) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_MISMATCH);
        goto err;
    }

    if (SSL_CONNECTION_IS_DTLS(s)) {
        int minversion, maxversion;

        if (!PACKET_get_length_prefixed_1(pkt, &cookie)) {
            SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_MISMATCH);
            goto err;
        }
        if (!PACKET_copy_all(&cookie, clienthello->dtls_cookie,
                sizeof(clienthello->dtls_cookie),
                &clienthello->dtls_cookie_len)) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }

        /*
         * If the connection supports DTLSv1.3:
         *      We continue to process ClientHello's without cookies
         *
         * Otherwise, if we require cookies and this ClientHello doesn't
         * contain one:
         *      Return since we do not want to allocate any memory yet
         */
        if ((SSL_get_options(SSL_CONNECTION_GET_SSL(s)) & SSL_OP_COOKIE_EXCHANGE)
            && clienthello->dtls_cookie_len == 0
            && ossl_assert(ssl_get_min_max_version(s, &minversion,
                               &maxversion, NULL)
                == 0)
            && ssl_version_cmp(s, maxversion, DTLS1_3_VERSION) < 0) {
            OPENSSL_free(clienthello);
            return MSG_PROCESS_FINISHED_READING;
        }
    }

    if (!PACKET_get_length_prefixed_2(pkt, &clienthello->ciphersuites)) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_MISMATCH);
        goto err;
    }

    if (!PACKET_get_length_prefixed_1(pkt, &compression)) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_MISMATCH);
        goto err;
    }

    /* Could be empty. */
    if (PACKET_remaining(pkt) == 0) {
        PACKET_null_init(&clienthello->extensions);
    } else {
        if (!PACKET_get_length_prefixed_2(pkt, &clienthello->extensions)
            || PACKET_remaining(pkt) != 0) {
            SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_MISMATCH);
            goto err;
        }
    }

    if (!PACKET_copy_all(&compression, clienthello->compressions,
            MAX_COMPRESSIONS_SIZE,
            &clienthello->compressions_len)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }

    /* Preserve the raw extensions PACKET for later use */
    extensions = clienthello->extensions;
    if (!tls_collect_extensions(s, &extensions, SSL_EXT_CLIENT_HELLO,
            &clienthello->pre_proc_exts,
            &clienthello->pre_proc_exts_len, 1)) {
        /* SSLfatal already been called */
        goto err;
    }

    if (SSL_CONNECTION_IS_DTLS(s)) {
        int minversion, maxversion;

        /*
         * If the connection supports DTLSv1.3 or if the ClientHello was sent
         * with the SupportedVersions extension:
         *      We continue to process ClientHello's without cookies
         *
         * Otherwise, if we require cookies and this ClientHello doesn't
         * contain one:
         *      Return since we do not want to allocate any memory yet
         */
        if ((SSL_get_options(SSL_CONNECTION_GET_SSL(s)) & SSL_OP_COOKIE_EXCHANGE)
            && clienthello->dtls_cookie_len == 0
            && ossl_assert(ssl_get_min_max_version(s, &minversion,
                               &maxversion, NULL)
                == 0)
            && ssl_version_cmp(s, maxversion, DTLS1_3_VERSION) < 0
            && !clienthello->pre_proc_exts[TLSEXT_IDX_supported_versions].present) {
            OPENSSL_free(clienthello->pre_proc_exts);
            OPENSSL_free(clienthello);
            return MSG_PROCESS_FINISHED_READING;
        }
    }

    s->clienthello = clienthello;

    return MSG_PROCESS_CONTINUE_PROCESSING;

err:
    if (clienthello != NULL)
        OPENSSL_free(clienthello->pre_proc_exts);
    OPENSSL_free(clienthello);
#ifndef OPENSSL_NO_ECH
    s->clienthello = NULL;
    OPENSSL_free(s->ext.ech.innerch);
    s->ext.ech.innerch = NULL;
    s->ext.ech.innerch_len = 0;
#endif

    return MSG_PROCESS_ERROR;
}

static int tls_early_post_process_client_hello(SSL_CONNECTION *s)
{
    unsigned int j;
    int i, al = SSL_AD_INTERNAL_ERROR;
    int protverr;
    unsigned long id;
#ifndef OPENSSL_NO_COMP
    SSL_COMP *comp = NULL;
#endif
    const SSL_CIPHER *c;
    STACK_OF(SSL_CIPHER) *ciphers = NULL;
    STACK_OF(SSL_CIPHER) *scsvs = NULL;
    CLIENTHELLO_MSG *clienthello = s->clienthello;
    DOWNGRADE dgrd = DOWNGRADE_NONE;
    SSL_CTX *sctx = SSL_CONNECTION_GET_CTX(s);
    SSL *ssl = SSL_CONNECTION_GET_SSL(s);
    SSL *ussl = SSL_CONNECTION_GET_USER_SSL(s);

    /* Finished parsing the ClientHello, now we can start processing it */
    /* Give the ClientHello callback a crack at things */
    if (sctx->client_hello_cb != NULL) {
        /* A failure in the ClientHello callback terminates the connection. */
        switch (sctx->client_hello_cb(ussl, &al, sctx->client_hello_cb_arg)) {
        case SSL_CLIENT_HELLO_SUCCESS:
            break;
        case SSL_CLIENT_HELLO_RETRY:
            s->rwstate = SSL_CLIENT_HELLO_CB;
            return -1;
        case SSL_CLIENT_HELLO_ERROR:
        default:
            SSLfatal(s, al, SSL_R_CALLBACK_FAILED);
            goto err;
        }
    }

    /* Set up the client_random */
    memcpy(s->s3.client_random, clienthello->random, SSL3_RANDOM_SIZE);

    /* Choose the server SSL/TLS/DTLS version. */
    protverr = ssl_choose_server_version(s, clienthello, &dgrd);

#ifndef OPENSSL_NO_ECH
    if (protverr && s->ext.ech.success == 1) {
        SSLfatal(s, SSL_AD_ILLEGAL_PARAMETER, protverr);
    }
#endif
    if (protverr) {
        if (SSL_IS_FIRST_HANDSHAKE(s)) {
            /* like ssl3_get_record, send alert using remote version number */
            s->version = s->client_version = clienthello->legacy_version;
        }
        SSLfatal(s, SSL_AD_PROTOCOL_VERSION, protverr);
        goto err;
    }

    /* TLSv1.3 specifies that a ClientHello must end on a record boundary */
    if (SSL_CONNECTION_IS_VERSION13(s)
        && RECORD_LAYER_processed_read_pending(&s->rlayer)) {
        SSLfatal(s, SSL_AD_UNEXPECTED_MESSAGE, SSL_R_NOT_ON_RECORD_BOUNDARY);
        goto err;
    }
    if (SSL_CONNECTION_IS_DTLS(s)) {
        if ((SSL_get_options(ssl) & SSL_OP_COOKIE_EXCHANGE) && clienthello->dtls_cookie_len != 0) {
            int verify_ret = 0;

#if !defined(OPENSSL_NO_DTLS)
            DTLS_LISTENER *dl = (DTLS_LISTENER *)s->d1->listener;

            if (dl != NULL && dl->require_hvr_cookie && sctx->app_verify_cookie_cb == NULL) {
                verify_ret = ossl_dtls_listener_verify_cookie_cb(ussl,
                    clienthello->dtls_cookie,
                    (unsigned int)clienthello->dtls_cookie_len);
            } else
#endif
                if (sctx->app_verify_cookie_cb != NULL) {
                verify_ret = sctx->app_verify_cookie_cb(ussl, clienthello->dtls_cookie,
                    (unsigned int)clienthello->dtls_cookie_len);
            } else if (s->d1->cookie_len == clienthello->dtls_cookie_len
                && memcmp(clienthello->dtls_cookie, s->d1->cookie,
                       s->d1->cookie_len)
                    == 0) {
                /* default verification succeeded */
                verify_ret = 1;
            }

            if (verify_ret == 0) {
                SSLfatal(s, SSL_AD_HANDSHAKE_FAILURE, SSL_R_COOKIE_MISMATCH);
                goto err;
            }
            s->d1->cookie_verified = 1;
        }
    }

    s->hit = 0;

    if (!ssl_cache_cipherlist(s, &clienthello->ciphersuites)
        || !ossl_bytes_to_cipher_list(s, &clienthello->ciphersuites, &ciphers, &scsvs, 1)) {
        /* SSLfatal() already called */
        goto err;
    }

    s->s3.send_connection_binding = 0;
    /* Check what signalling cipher-suite values were received. */
    if (scsvs != NULL) {
        for (i = 0; i < sk_SSL_CIPHER_num(scsvs); i++) {
            c = sk_SSL_CIPHER_value(scsvs, i);
            if (SSL_CIPHER_get_id(c) == SSL3_CK_SCSV) {
                if (s->renegotiate) {
                    /* SCSV is fatal if renegotiating */
                    SSLfatal(s, SSL_AD_HANDSHAKE_FAILURE,
                        SSL_R_SCSV_RECEIVED_WHEN_RENEGOTIATING);
                    goto err;
                }
                s->s3.send_connection_binding = 1;
            } else if (SSL_CIPHER_get_id(c) == SSL3_CK_FALLBACK_SCSV && !ssl_check_version_downgrade(s)) {
                /*
                 * This SCSV indicates that the client previously tried
                 * a higher version.  We should fail if the current version
                 * is an unexpected downgrade, as that indicates that the first
                 * connection may have been tampered with in order to trigger
                 * an insecure downgrade.
                 */
                SSLfatal(s, SSL_AD_INAPPROPRIATE_FALLBACK,
                    SSL_R_INAPPROPRIATE_FALLBACK);
                goto err;
            }
        }
    }

    /* For TLSv1.3 we must select the ciphersuite *before* session resumption */
    if (SSL_CONNECTION_IS_VERSION13(s)) {
        const SSL_CIPHER *cipher = ssl3_choose_cipher(s, ciphers, SSL_get_ciphers(ssl));

        if (cipher == NULL) {
            SSLfatal(s, SSL_AD_HANDSHAKE_FAILURE, SSL_R_NO_SHARED_CIPHER);
            goto err;
        }
        if (s->hello_retry_request == SSL_HRR_PENDING
            && (s->s3.tmp.new_cipher == NULL
                || s->s3.tmp.new_cipher->id != cipher->id)) {
            /*
             * A previous HRR picked a different ciphersuite to the one we
             * just selected. Something must have changed.
             */
            SSLfatal(s, SSL_AD_ILLEGAL_PARAMETER, SSL_R_BAD_CIPHER);
            goto err;
        }
        s->s3.tmp.new_cipher = cipher;
    }

    /* We need to do this before getting the session */
    if (!tls_parse_extension(s, TLSEXT_IDX_extended_master_secret,
            SSL_EXT_CLIENT_HELLO,
            clienthello->pre_proc_exts, NULL, 0)) {
        /* SSLfatal() already called */
        goto err;
    }

    /*
     * We don't allow resumption in a backwards compatible ClientHello.
     * In TLS1.1+, session_id MUST be empty.
     *
     * Versions before 0.9.7 always allow clients to resume sessions in
     * renegotiation. 0.9.7 and later allow this by default, but optionally
     * ignore resumption requests with flag
     * SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION (it's a new flag rather
     * than a change to default behavior so that applications relying on
     * this for security won't even compile against older library versions).
     * 1.0.1 and later also have a function SSL_renegotiate_abbreviated() to
     * request renegotiation but not a new session (s->new_session remains
     * unset): for servers, this essentially just means that the
     * SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION setting will be
     * ignored.
     */
    if (s->new_session && (s->options & SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION)) {
        if (!ssl_get_new_session(s, 1)) {
            /* SSLfatal() already called */
            goto err;
        }
    } else {
        i = ssl_get_prev_session(s, clienthello);
        if (i == 1) {
            /* previous session */
            s->hit = 1;
        } else if (i == -1) {
            /* SSLfatal() already called */
            goto err;
        } else {
            /* i == 0 */
            if (!ssl_get_new_session(s, 1)) {
                /* SSLfatal() already called */
                goto err;
            }
        }
    }

    if (SSL_CONNECTION_IS_VERSION13(s)) {
        memcpy(s->tmp_session_id, s->clienthello->session_id,
            s->clienthello->session_id_len);
        s->tmp_session_id_len = s->clienthello->session_id_len;
    }

    /*
     * If it is a hit, check that the cipher is in the list. In TLSv1.3 we check
     * ciphersuite compatibility with the session as part of resumption.
     */
    if (!SSL_CONNECTION_IS_VERSION13(s) && s->hit) {
        j = 0;
        id = s->session->cipher->id;

        OSSL_TRACE_BEGIN(TLS_CIPHER)
        {
            BIO_printf(trc_out, "client sent %d ciphers\n",
                sk_SSL_CIPHER_num(ciphers));
        }
        for (i = 0; i < sk_SSL_CIPHER_num(ciphers); i++) {
            c = sk_SSL_CIPHER_value(ciphers, i);
            if (trc_out != NULL)
                BIO_printf(trc_out, "client [%2d of %2d]:%s\n", i,
                    sk_SSL_CIPHER_num(ciphers), SSL_CIPHER_get_name(c));
            if (c->id == id) {
                j = 1;
                break;
            }
        }
        if (j == 0) {
            /*
             * we need to have the cipher in the cipher list if we are asked
             * to reuse it
             */
            SSLfatal(s, SSL_AD_ILLEGAL_PARAMETER,
                SSL_R_REQUIRED_CIPHER_MISSING);
            OSSL_TRACE_CANCEL(TLS_CIPHER);
            goto err;
        }
        OSSL_TRACE_END(TLS_CIPHER);
    }

    /* At least one compression method must be preset. */
    if (clienthello->compressions_len == 0) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_NO_COMPRESSION_SPECIFIED);
        goto err;
    }
    /* Make sure at least the null compression is supported. */
    if (memchr(clienthello->compressions, 0,
            clienthello->compressions_len)
        == NULL) {
        SSLfatal(s, SSL_AD_ILLEGAL_PARAMETER,
            SSL_R_REQUIRED_COMPRESSION_ALGORITHM_MISSING);
        goto err;
    }

    if (s->options & SSL_OP_SAFARI_ECDHE_ECDSA_BUG)
        ssl_check_for_safari(s, clienthello);

    /* TLS extensions */
    if (!tls_parse_all_extensions(s, SSL_EXT_CLIENT_HELLO,
            clienthello->pre_proc_exts, NULL, 0, 1)) {
        /* SSLfatal() already called */
        goto err;
    }

    /*
     * Check if we want to use external pre-shared secret for this handshake
     * for not reused session only. We need to generate server_random before
     * calling tls_session_secret_cb in order to allow SessionTicket
     * processing to use it in key derivation.
     */
    {
        unsigned char *pos;
        pos = s->s3.server_random;
        if (ssl_fill_hello_random(s, 1, pos, SSL3_RANDOM_SIZE, dgrd) <= 0) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }
    }

    if (!s->hit && !tls1_set_server_sigalgs(s)) {
        /* SSLfatal() already called */
        goto err;
    }

    /*
     * Unless ECH has worked or not been configured we won't call
     * the session_secret_cb now because we'll need to calculate the
     * server random later to include the ECH accept value.
     * We can't do it now as we don't yet have the SH encoding.
     */
    if (
#ifndef OPENSSL_NO_ECH
        ((s->ext.ech.es != NULL && s->ext.ech.success == 1)
            || s->ext.ech.es == NULL)
        &&
#endif
        !s->hit
        && s->version >= TLS1_VERSION
        && !SSL_CONNECTION_IS_VERSION13(s)
        && !SSL_CONNECTION_IS_DTLS(s)
        && s->ext.session_secret_cb != NULL) {
        const SSL_CIPHER *pref_cipher = NULL;

        /*
         * s->session->master_key_length is a size_t, but this is an int for
         * backwards compat reasons
         */
        int master_key_length;

        master_key_length = sizeof(s->session->master_key);
        if (s->ext.session_secret_cb(ussl, s->session->master_key,
                &master_key_length, ciphers,
                &pref_cipher,
                s->ext.session_secret_cb_arg)
            && master_key_length > 0) {
            s->session->master_key_length = master_key_length;
            s->hit = 1;
            s->peer_ciphers = ciphers;
            s->session->verify_result = X509_V_OK;

            /*
             * Per RFC 4851, Section 3.2.2:
             * If the ClientHello contains both a Session ID and a PAC-Opaque in
             * the SessionTicket extension, and the server resumes the session
             * using the PAC-Opaque, it should echo the same Session ID in the
             * ServerHello.
             */
            if (clienthello->session_id_len > 0) {
                memcpy(s->session->session_id, clienthello->session_id,
                    clienthello->session_id_len);
                s->session->session_id_length = clienthello->session_id_len;
            }

            ciphers = NULL;

            /* check if some cipher was preferred by call back */
            if (pref_cipher == NULL)
                pref_cipher = ssl3_choose_cipher(s, s->peer_ciphers,
                    SSL_get_ciphers(ssl));
            if (pref_cipher == NULL) {
                SSLfatal(s, SSL_AD_HANDSHAKE_FAILURE, SSL_R_NO_SHARED_CIPHER);
                goto err;
            }

            s->session->cipher = pref_cipher;
            sk_SSL_CIPHER_free(s->cipher_list);
            s->cipher_list = sk_SSL_CIPHER_dup(s->peer_ciphers);
            sk_SSL_CIPHER_free(s->cipher_list_by_id);
            s->cipher_list_by_id = sk_SSL_CIPHER_dup(s->peer_ciphers);
        }
    }

    /*
     * Worst case, we will use the NULL compression, but if we have other
     * options, we will now look for them.  We have complen-1 compression
     * algorithms from the client, starting at q.
     */
    s->s3.tmp.new_compression = NULL;
    if (SSL_CONNECTION_IS_VERSION13(s)) {
        /*
         * We already checked above that the NULL compression method appears in
         * the list. Now we check there aren't any others (which is illegal in
         * a TLSv1.3 ClientHello.
         */
        if (clienthello->compressions_len != 1) {
            SSLfatal(s, SSL_AD_ILLEGAL_PARAMETER,
                SSL_R_INVALID_COMPRESSION_ALGORITHM);
            goto err;
        }
    }
#ifndef OPENSSL_NO_COMP
    /* This only happens if we have a cache hit */
    else if (s->session->compress_meth != 0) {
        int m, comp_id = s->session->compress_meth;
        unsigned int k;
        /* Perform sanity checks on resumed compression algorithm */
        /* Can't disable compression */
        if (!ssl_allow_compression(s)) {
            SSLfatal(s, SSL_AD_HANDSHAKE_FAILURE,
                SSL_R_INCONSISTENT_COMPRESSION);
            goto err;
        }
        /* Look for resumed compression method */
        for (m = 0; m < sk_SSL_COMP_num(sctx->comp_methods); m++) {
            comp = sk_SSL_COMP_value(sctx->comp_methods, m);
            if (comp_id == comp->id) {
                s->s3.tmp.new_compression = comp;
                break;
            }
        }
        if (s->s3.tmp.new_compression == NULL) {
            SSLfatal(s, SSL_AD_HANDSHAKE_FAILURE,
                SSL_R_INVALID_COMPRESSION_ALGORITHM);
            goto err;
        }
        /* Look for resumed method in compression list */
        for (k = 0; k < clienthello->compressions_len; k++) {
            if (clienthello->compressions[k] == comp_id)
                break;
        }
        if (k >= clienthello->compressions_len) {
            SSLfatal(s, SSL_AD_ILLEGAL_PARAMETER,
                SSL_R_REQUIRED_COMPRESSION_ALGORITHM_MISSING);
            goto err;
        }
    } else if (s->hit) {
        comp = NULL;
    } else if (ssl_allow_compression(s) && sctx->comp_methods) {
        /* See if we have a match */
        int m, nn, v, done = 0;
        unsigned int o;

        nn = sk_SSL_COMP_num(sctx->comp_methods);
        for (m = 0; m < nn; m++) {
            comp = sk_SSL_COMP_value(sctx->comp_methods, m);
            v = comp->id;
            for (o = 0; o < clienthello->compressions_len; o++) {
                if (v == clienthello->compressions[o]) {
                    done = 1;
                    break;
                }
            }
            if (done)
                break;
        }
        if (done)
            s->s3.tmp.new_compression = comp;
        else
            comp = NULL;
    }
#else
    /*
     * If compression is disabled we'd better not try to resume a session
     * using compression.
     */
    if (s->session->compress_meth != 0) {
        SSLfatal(s, SSL_AD_HANDSHAKE_FAILURE, SSL_R_INCONSISTENT_COMPRESSION);
        goto err;
    }
#endif

    /*
     * Given s->peer_ciphers and SSL_get_ciphers, we must pick a cipher
     */

    if (!s->hit || SSL_CONNECTION_IS_VERSION13(s)) {
        sk_SSL_CIPHER_free(s->peer_ciphers);
        s->peer_ciphers = ciphers;
        if (ciphers == NULL) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }
        ciphers = NULL;
    }

    if (!s->hit) {
#ifdef OPENSSL_NO_COMP
        s->session->compress_meth = 0;
#else
        s->session->compress_meth = (comp == NULL) ? 0 : comp->id;
#endif
    }

    sk_SSL_CIPHER_free(ciphers);
    sk_SSL_CIPHER_free(scsvs);
    OPENSSL_free(clienthello->pre_proc_exts);
    OPENSSL_free(s->clienthello);
    s->clienthello = NULL;
    return 1;
err:
    sk_SSL_CIPHER_free(ciphers);
    sk_SSL_CIPHER_free(scsvs);
    if (clienthello != NULL)
        OPENSSL_free(clienthello->pre_proc_exts);
    OPENSSL_free(s->clienthello);
    s->clienthello = NULL;

    return 0;
}

/*
 * Call the status request callback if needed. Upon success, returns 1.
 * Upon failure, returns 0.
 */
static int tls_handle_status_request(SSL_CONNECTION *s)
{
    SSL_CTX *sctx = SSL_CONNECTION_GET_CTX(s);

    s->ext.status_expected = 0;

    /*
     * If status request then ask callback what to do. Note: this must be
     * called after servername callbacks in case the certificate has changed,
     * and must be called after the cipher has been chosen because this may
     * influence which certificate is sent
     */
    if (s->ext.status_type != TLSEXT_STATUSTYPE_nothing && sctx != NULL
        && sctx->ext.status_cb != NULL) {
        int ret;

        /* If no certificate can't return certificate status */
        if (s->s3.tmp.cert != NULL) {
            /*
             * Set current certificate to one we will use so SSL_get_certificate
             * et al can pick it up.
             */
            s->cert->key = s->s3.tmp.cert;
            ret = sctx->ext.status_cb(SSL_CONNECTION_GET_USER_SSL(s),
                sctx->ext.status_arg);
            switch (ret) {
                /* We don't want to send a status request response */
            case SSL_TLSEXT_ERR_NOACK:
                s->ext.status_expected = 0;
                break;
                /* status request response should be sent */
            case SSL_TLSEXT_ERR_OK:
#ifndef OPENSSL_NO_OCSP
                if (s->ext.ocsp.resp_ex != NULL
                    && sk_OCSP_RESPONSE_num(s->ext.ocsp.resp_ex) > 0)
                    s->ext.status_expected = 1;
#endif
                break;
                /* something bad happened */
            case SSL_TLSEXT_ERR_ALERT_FATAL:
            default:
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_CLIENTHELLO_TLSEXT);
                return 0;
            }
        }
    }

    return 1;
}

/*
 * Call the alpn_select callback if needed. Upon success, returns 1.
 * Upon failure, returns 0.
 */
int tls_handle_alpn(SSL_CONNECTION *s)
{
    const unsigned char *selected = NULL;
    unsigned char selected_len = 0;
    SSL_CTX *sctx = SSL_CONNECTION_GET_CTX(s);

    if (sctx->ext.alpn_select_cb != NULL && s->s3.alpn_proposed != NULL) {
        int r = sctx->ext.alpn_select_cb(SSL_CONNECTION_GET_USER_SSL(s),
            &selected, &selected_len,
            s->s3.alpn_proposed,
            (unsigned int)s->s3.alpn_proposed_len,
            sctx->ext.alpn_select_cb_arg);

        if (r == SSL_TLSEXT_ERR_OK) {
            OPENSSL_free(s->s3.alpn_selected);
            s->s3.alpn_selected = OPENSSL_memdup(selected, selected_len);
            if (s->s3.alpn_selected == NULL) {
                s->s3.alpn_selected_len = 0;
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                return 0;
            }
            s->s3.alpn_selected_len = selected_len;
#ifndef OPENSSL_NO_NEXTPROTONEG
            /* ALPN takes precedence over NPN. */
            s->s3.npn_seen = 0;
#endif

            /* Check ALPN is consistent with session */
            if (s->session->ext.alpn_selected == NULL
                || selected_len != s->session->ext.alpn_selected_len
                || memcmp(selected, s->session->ext.alpn_selected,
                       selected_len)
                    != 0) {
                /* Not consistent so can't be used for early_data */
                s->ext.early_data_ok = 0;

                if (!s->hit) {
                    /*
                     * This is a new session and so alpn_selected should have
                     * been initialised to NULL. We should update it with the
                     * selected ALPN.
                     */
                    if (!ossl_assert(s->session->ext.alpn_selected == NULL)) {
                        SSLfatal(s, SSL_AD_INTERNAL_ERROR,
                            ERR_R_INTERNAL_ERROR);
                        return 0;
                    }
                    s->session->ext.alpn_selected = OPENSSL_memdup(selected,
                        selected_len);
                    if (s->session->ext.alpn_selected == NULL) {
                        SSLfatal(s, SSL_AD_INTERNAL_ERROR,
                            ERR_R_INTERNAL_ERROR);
                        return 0;
                    }
                    s->session->ext.alpn_selected_len = selected_len;
                }
            }

            return 1;
        } else if (r != SSL_TLSEXT_ERR_NOACK) {
            SSLfatal(s, SSL_AD_NO_APPLICATION_PROTOCOL,
                SSL_R_NO_APPLICATION_PROTOCOL);
            return 0;
        }
        /*
         * If r == SSL_TLSEXT_ERR_NOACK then behave as if no callback was
         * present.
         */
    }

    /* Check ALPN is consistent with session */
    if (s->session->ext.alpn_selected != NULL) {
        /* Not consistent so can't be used for early_data */
        s->ext.early_data_ok = 0;
    }

    return 1;
}

WORK_STATE tls_post_process_client_hello(SSL_CONNECTION *s, WORK_STATE wst)
{
    const SSL_CIPHER *cipher;
    SSL *ssl = SSL_CONNECTION_GET_SSL(s);
    SSL *ussl = SSL_CONNECTION_GET_USER_SSL(s);

    if (wst == WORK_MORE_A) {
        int rv = tls_early_post_process_client_hello(s);

        if (rv == 0) {
            /* SSLfatal() was already called */
            goto err;
        }
        if (rv < 0)
            return WORK_MORE_A;
        wst = WORK_MORE_B;
    }
    if (wst == WORK_MORE_B) {
        if (!s->hit || SSL_CONNECTION_IS_VERSION13(s)) {
            /* Let cert callback update server certificates if required */
            if (!s->hit && s->cert->cert_cb != NULL) {
                int rv = s->cert->cert_cb(ussl, s->cert->cert_cb_arg);

                if (rv == 0) {
                    SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_CERT_CB_ERROR);
                    goto err;
                }
                if (rv < 0) {
                    s->rwstate = SSL_X509_LOOKUP;
                    return WORK_MORE_B;
                }
                s->rwstate = SSL_NOTHING;
            }

            /* In TLSv1.3 we selected the ciphersuite before resumption */
            if (!SSL_CONNECTION_IS_VERSION13(s)) {
                cipher = ssl3_choose_cipher(s, s->peer_ciphers,
                    SSL_get_ciphers(ssl));

                if (cipher == NULL) {
                    SSLfatal(s, SSL_AD_HANDSHAKE_FAILURE,
                        SSL_R_NO_SHARED_CIPHER);
                    goto err;
                }
                s->s3.tmp.new_cipher = cipher;
            }
            if (!s->hit) {
                if (!tls_choose_sigalg(s, 1)) {
                    /* SSLfatal already called */
                    goto err;
                }
                /* check whether we should disable session resumption */
                if (s->not_resumable_session_cb != NULL)
                    s->session->not_resumable = s->not_resumable_session_cb(ussl,
                        ((s->s3.tmp.new_cipher->algorithm_mkey
                             & (SSL_kDHE | SSL_kECDHE))
                            != 0));
                if (s->session->not_resumable)
                    /* do not send a session ticket */
                    s->ext.ticket_expected = 0;
            }
        } else {
            /* Session-id reuse */
            s->s3.tmp.new_cipher = s->session->cipher;
        }

        /*
         * Call status_request callback if needed. Has to be done after the
         * certificate callbacks etc above.
         */
        if (!tls_handle_status_request(s)) {
            /* SSLfatal() already called */
            goto err;
        }
        /*
         * Call alpn_select callback if needed.  Has to be done after SNI and
         * cipher negotiation (HTTP/2 restricts permitted ciphers). In TLSv1.3
         * we already did this because cipher negotiation happens earlier, and
         * we must handle ALPN before we decide whether to accept early_data.
         */
        if (!SSL_CONNECTION_IS_VERSION13(s) && !tls_handle_alpn(s)) {
            /* SSLfatal() already called */
            goto err;
        }

        wst = WORK_MORE_C;
    }
#ifndef OPENSSL_NO_SRP
    if (wst == WORK_MORE_C) {
        int ret;
        if ((ret = ssl_check_srp_ext_ClientHello(s)) == 0) {
            /*
             * callback indicates further work to be done
             */
            s->rwstate = SSL_X509_LOOKUP;
            return WORK_MORE_C;
        }
        if (ret < 0) {
            /* SSLfatal() already called */
            goto err;
        }
    }
#endif

    return WORK_FINISHED_STOP;
err:
    return WORK_ERROR;
}

CON_FUNC_RETURN tls_construct_server_hello(SSL_CONNECTION *s, WPACKET *pkt)
{
    int compm;
    size_t sl, len;
    int version;
    unsigned char *session_id;
    int usetls13 = SSL_CONNECTION_IS_TLS13(s)
        || (!SSL_CONNECTION_IS_DTLS(s)
            && s->hello_retry_request == SSL_HRR_PENDING);
    int usedtls13 = SSL_CONNECTION_IS_DTLS13(s)
        || (SSL_CONNECTION_IS_DTLS(s)
            && s->hello_retry_request == SSL_HRR_PENDING);

    version = usetls13 ? TLS1_2_VERSION : (usedtls13 ? DTLS1_2_VERSION : s->version);
    if (!WPACKET_put_bytes_u16(pkt, version)
        /*
         * Random stuff. Filling of the server_random takes place in
         * tls_process_client_hello()
         */
        || !WPACKET_memcpy(pkt,
            s->hello_retry_request == SSL_HRR_PENDING
                ? hrrrandom
                : s->s3.server_random,
            SSL3_RANDOM_SIZE)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return CON_FUNC_ERROR;
    }

    /*-
     * There are several cases for the session ID to send
     * back in the server hello:
     * - For session reuse from the session cache,
     *   we send back the old session ID.
     * - If stateless session reuse (using a session ticket)
     *   is successful, we send back the client's "session ID"
     *   (which doesn't actually identify the session).
     * - If it is a new session, we send back the new
     *   session ID.
     * - However, if we want the new session to be single-use,
     *   we send back a 0-length session ID.
     * - In TLSv1.3 we echo back the session id sent to us by the client
     *   regardless
     * - In DTLSv1.3 we must not echo the session id sent by the client
     * s->hit is non-zero in either case of session reuse,
     * so the following won't overwrite an ID that we're supposed
     * to send back.
     */
    if (!(SSL_CONNECTION_GET_CTX(s)->session_cache_mode & SSL_SESS_CACHE_SERVER)
        && !s->hit)
        s->session->session_id_length = 0;

    if (usetls13) {
        sl = s->tmp_session_id_len;
        session_id = s->tmp_session_id;
    } else if (usedtls13) {
        sl = 0;
        session_id = NULL;
    } else {
        sl = s->session->session_id_length;
        session_id = s->session->session_id;
    }

    if (sl > sizeof(s->session->session_id)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return CON_FUNC_ERROR;
    }

    /* set up the compression method */
#ifdef OPENSSL_NO_COMP
    compm = 0;
#else
    if (usetls13 || usedtls13 || s->s3.tmp.new_compression == NULL)
        compm = 0;
    else
        compm = s->s3.tmp.new_compression->id;
#endif

    if (!WPACKET_sub_memcpy_u8(pkt, session_id, sl)
        || !SSL_CONNECTION_GET_SSL(s)->method->put_cipher_by_char(s->s3.tmp.new_cipher,
            pkt, &len)
        || !WPACKET_put_bytes_u8(pkt, compm)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return CON_FUNC_ERROR;
    }

    if (!tls_construct_extensions(s, pkt,
            s->hello_retry_request == SSL_HRR_PENDING
                ? SSL_EXT_TLS1_3_HELLO_RETRY_REQUEST
                : (SSL_CONNECTION_IS_VERSION13(s)
                          ? SSL_EXT_TLS1_3_SERVER_HELLO
                          : SSL_EXT_TLS1_2_SERVER_HELLO),
            NULL, 0)) {
        /* SSLfatal() already called */
        return CON_FUNC_ERROR;
    }

    if (s->hello_retry_request == SSL_HRR_PENDING) {
        /* Ditch the session. We'll create a new one next time around */
        SSL_SESSION_free(s->session);
        s->session = NULL;
        s->hit = 0;

        /*
         * Re-initialise the Transcript Hash. We're going to prepopulate it with
         * a synthetic message_hash in place of ClientHello1.
         */
#ifndef OPENSSL_NO_ECH
        /*
         * if we're sending 2nd SH after HRR and we did ECH
         * then we want to inject the hash of the inner CH1
         * and not the outer (which is the default)
         */
        OSSL_TRACE_BEGIN(TLS)
        {
            BIO_printf(trc_out, "Checking success (%d)/innerCH (%p)\n",
                s->ext.ech.success, (void *)s->ext.ech.innerch);
        }
        OSSL_TRACE_END(TLS);
        if ((s->ext.ech.backend == 1 || s->ext.ech.success == 1)
            && s->ext.ech.innerch != NULL) {
            /* do pre-existing HRR stuff */
            unsigned char hashval[EVP_MAX_MD_SIZE];
            unsigned int hashlen;
            EVP_MD_CTX *ctx = EVP_MD_CTX_new();
            const EVP_MD *md = NULL;

            OSSL_TRACE(TLS, "Adding in digest of ClientHello\n");
#ifdef OSSL_ECH_SUPERVERBOSE
            ossl_ech_pbuf("innerch", s->ext.ech.innerch,
                s->ext.ech.innerch_len);
#endif
            if (ctx == NULL) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                return CON_FUNC_ERROR;
            }
            md = ssl_handshake_md(s);
            if (md == NULL) {
                EVP_MD_CTX_free(ctx);
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                return CON_FUNC_ERROR;
            }
            if (EVP_DigestInit_ex(ctx, md, NULL) <= 0
                || EVP_DigestUpdate(ctx, s->ext.ech.innerch,
                       s->ext.ech.innerch_len)
                    <= 0
                || EVP_DigestFinal_ex(ctx, hashval, &hashlen) <= 0) {
                EVP_MD_CTX_free(ctx);
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                return CON_FUNC_ERROR;
            }
#ifdef OSSL_ECH_SUPERVERBOSE
            ossl_ech_pbuf("digested CH", hashval, hashlen);
#endif
            EVP_MD_CTX_free(ctx);
            if (ossl_ech_reset_hs_buffer(s, NULL, 0) != 1) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                return CON_FUNC_ERROR;
            }
            if (!create_synthetic_message_hash(s, hashval, hashlen, NULL, 0)) {
                /* SSLfatal() already called */
                return CON_FUNC_ERROR;
            }
        } else {
            if (!create_synthetic_message_hash(s, NULL, 0, NULL, 0))
                return CON_FUNC_ERROR; /* SSLfatal() already called */
        }
#else
        if (!create_synthetic_message_hash(s, NULL, 0, NULL, 0))
            /* SSLfatal() already called */
            return CON_FUNC_ERROR;
#endif /* OPENSSL_NO_ECH */
    } else if (!(s->verify_mode & SSL_VERIFY_PEER)
        && !ssl3_digest_cached_records(s, 0)) {
        /* SSLfatal() already called */;
        return CON_FUNC_ERROR;
    }

#ifndef OPENSSL_NO_ECH
    /*
     * Calculate the ECH-accept server random to indicate that
     * we're accepting ECH, if that's the case
     */
    if (s->ext.ech.attempted_type == TLSEXT_TYPE_ech
        && (s->ext.ech.backend == 1
            || (s->ext.ech.es != NULL && s->ext.ech.success == 1))) {
        unsigned char acbuf[8];
        unsigned char *shbuf = NULL;
        size_t shlen = 0;
        size_t shoffset = 0;
        int hrr = 0;

        if (s->hello_retry_request == SSL_HRR_PENDING)
            hrr = 1;
        memset(acbuf, 0, 8);
        if (WPACKET_get_total_written(pkt, &shlen) != 1) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            return CON_FUNC_ERROR;
        }
        shbuf = WPACKET_get_curr(pkt) - shlen;
        /* we need to fixup SH length here */
        shbuf[1] = ((shlen - 4)) >> 16 & 0xff;
        shbuf[2] = ((shlen - 4)) >> 8 & 0xff;
        shbuf[3] = (shlen - 4) & 0xff;
        if (ossl_ech_intbuf_add(s, shbuf, shlen, hrr) != 1) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            return CON_FUNC_ERROR;
        }
        if (ossl_ech_calc_confirm(s, hrr, acbuf, shlen) != 1) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            return CON_FUNC_ERROR;
        }
        memcpy(s->s3.server_random + SSL3_RANDOM_SIZE - 8, acbuf, 8);
        if (hrr == 0) {
            /* confirm value hacked into SH.random rightmost octets */
            shoffset = SSL3_HM_HEADER_LENGTH /* 4 */
                + CLIENT_VERSION_LEN /* 2 */
                + SSL3_RANDOM_SIZE /* 32 */
                - 8;
            memcpy(shbuf + shoffset, acbuf, 8);
        } else {
            /*
             * confirm value is in extension in HRR case as the SH.random
             * is already hacked to be a specific value in a HRR
             */
            memcpy(WPACKET_get_curr(pkt) - 8, acbuf, 8);
        }
    }
    /* call ECH callback, if appropriate */
    if (s->ext.ech.attempted == 1 && s->ext.ech.cb != NULL
        && s->hello_retry_request != SSL_HRR_PENDING) {
        char pstr[OSSL_ECH_PBUF_SIZE + 1];
        BIO *biom = BIO_new(BIO_s_mem());
        unsigned int cbrv = 0;

        if (biom == NULL) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            return CON_FUNC_ERROR;
        }
        memset(pstr, 0, OSSL_ECH_PBUF_SIZE + 1);
        ossl_ech_status_print(biom, s, OSSL_ECHSTORE_ALL);
        BIO_read(biom, pstr, OSSL_ECH_PBUF_SIZE);
        cbrv = s->ext.ech.cb(&s->ssl, pstr);
        BIO_free(biom);
        if (cbrv != 1) {
            OSSL_TRACE(TLS, "Error from tls_construct_server_hello/ech_cb\n");
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            return CON_FUNC_ERROR;
        }
    }
#endif /* OPENSSL_NO_ECH */
    return CON_FUNC_SUCCESS;
}

CON_FUNC_RETURN tls_construct_server_done(SSL_CONNECTION *s, WPACKET *pkt)
{
    if (s->s3.tmp.cert_request == 0) {
        if (!ssl3_digest_cached_records(s, 0)) {
            /* SSLfatal() already called */
            return CON_FUNC_ERROR;
        }
    }
    return CON_FUNC_SUCCESS;
}

CON_FUNC_RETURN tls_construct_server_key_exchange(SSL_CONNECTION *s,
    WPACKET *pkt)
{
    EVP_PKEY *pkdh = NULL;
    unsigned char *encodedPoint = NULL;
    size_t encodedlen = 0;
    int group_id = 0;
    const SIGALG_LOOKUP *lu = s->s3.tmp.sigalg;
    int i;
    unsigned long type;
    BIGNUM *r[4];
    EVP_MD_CTX *md_ctx = EVP_MD_CTX_new();
    EVP_PKEY_CTX *pctx = NULL;
    size_t paramlen, paramoffset;
    int freer = 0;
    CON_FUNC_RETURN ret = CON_FUNC_ERROR;
    SSL_CTX *sctx = SSL_CONNECTION_GET_CTX(s);

    if (!WPACKET_get_total_written(pkt, &paramoffset)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }

    if (md_ctx == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_EVP_LIB);
        goto err;
    }

    type = s->s3.tmp.new_cipher->algorithm_mkey;

    r[0] = r[1] = r[2] = r[3] = NULL;
#ifndef OPENSSL_NO_PSK
    /* Plain PSK or RSAPSK nothing to do */
    if (type & (SSL_kPSK | SSL_kRSAPSK)) {
    } else
#endif /* !OPENSSL_NO_PSK */
        if (type & (SSL_kDHE | SSL_kDHEPSK)) {
            CERT *cert = s->cert;
            EVP_PKEY *pkdhp = NULL;

            /* Get NID of appropriate shared FFDHE group */
            group_id = tls1_shared_group(s, TLS1_GROUPS_RETURN_TMP_ID,
                TLS1_GROUPS_FFDHE_GROUPS);
            if (group_id != 0) {
                /* Cache the group used in the SSL_SESSION */
                s->session->kex_group = group_id;

                s->s3.tmp.pkey = ssl_generate_pkey_group(s, group_id);
                if (s->s3.tmp.pkey == NULL) {
                    SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                    goto err;
                }
            } else {

                if (s->cert->dh_tmp_auto) {
                    pkdh = ssl_get_auto_dh(s);
                    if (pkdh == NULL) {
                        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                        goto err;
                    }
                    pkdhp = pkdh;
                } else {
                    pkdhp = cert->dh_tmp;
                }
#if !defined(OPENSSL_NO_DEPRECATED_3_0)
                if ((pkdhp == NULL) && (s->cert->dh_tmp_cb != NULL)) {
                    pkdh = ssl_dh_to_pkey(
                        s->cert->dh_tmp_cb(SSL_CONNECTION_GET_USER_SSL(s), 0, 1024));
                    if (pkdh == NULL) {
                        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                        goto err;
                    }
                    pkdhp = pkdh;
                }
#endif
                if (pkdhp == NULL) {
                    SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_MISSING_TMP_DH_KEY);
                    goto err;
                }
                if (!ssl_security(s, SSL_SECOP_TMP_DH,
                        EVP_PKEY_get_security_bits(pkdhp), 0, pkdhp)) {
                    SSLfatal(s, SSL_AD_HANDSHAKE_FAILURE, SSL_R_DH_KEY_TOO_SMALL);
                    goto err;
                }
                if (s->s3.tmp.pkey != NULL) {
                    SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                    goto err;
                }

                s->s3.tmp.pkey = ssl_generate_pkey(s, pkdhp);
                if (s->s3.tmp.pkey == NULL) {
                    SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                    goto err;
                }

                EVP_PKEY_free(pkdh);
                pkdh = NULL;
            }

            /* These BIGNUMs need to be freed when we're finished */
            freer = 1;
            if (!EVP_PKEY_get_bn_param(s->s3.tmp.pkey, OSSL_PKEY_PARAM_FFC_P,
                    &r[0])
                || !EVP_PKEY_get_bn_param(s->s3.tmp.pkey, OSSL_PKEY_PARAM_FFC_G,
                    &r[1])
                || !EVP_PKEY_get_bn_param(s->s3.tmp.pkey,
                    OSSL_PKEY_PARAM_PUB_KEY, &r[2])) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                goto err;
            }
        } else if (type & (SSL_kECDHE | SSL_kECDHEPSK)) {

            if (s->s3.tmp.pkey != NULL) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                goto err;
            }

            /* Get NID of appropriate shared ECDHE curve */
            group_id = tls1_shared_group(s, TLS1_GROUPS_RETURN_TMP_ID,
                TLS1_GROUPS_NON_FFDHE_GROUPS);
            if (group_id == 0) {
                SSLfatal(s, SSL_AD_HANDSHAKE_FAILURE,
                    SSL_R_UNSUPPORTED_ELLIPTIC_CURVE);
                goto err;
            }
            /* Cache the group used in the SSL_SESSION */
            s->session->kex_group = group_id;
            /* Generate a new key for this curve */
            s->s3.tmp.pkey = ssl_generate_pkey_group(s, group_id);
            if (s->s3.tmp.pkey == NULL) {
                /* SSLfatal() already called */
                goto err;
            }

            /* Encode the public key. */
            encodedlen = EVP_PKEY_get1_encoded_public_key(s->s3.tmp.pkey,
                &encodedPoint);
            if (encodedlen == 0) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_EC_LIB);
                goto err;
            }

            /*
             * We'll generate the serverKeyExchange message explicitly so we
             * can set these to NULLs
             */
            r[0] = NULL;
            r[1] = NULL;
            r[2] = NULL;
            r[3] = NULL;
        } else
#ifndef OPENSSL_NO_SRP
            if (type & SSL_kSRP) {
            if ((s->srp_ctx.N == NULL) || (s->srp_ctx.g == NULL) || (s->srp_ctx.s == NULL) || (s->srp_ctx.B == NULL)) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_MISSING_SRP_PARAM);
                goto err;
            }
            r[0] = s->srp_ctx.N;
            r[1] = s->srp_ctx.g;
            r[2] = s->srp_ctx.s;
            r[3] = s->srp_ctx.B;
        } else
#endif
        {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_UNKNOWN_KEY_EXCHANGE_TYPE);
            goto err;
        }

    if (((s->s3.tmp.new_cipher->algorithm_auth & (SSL_aNULL | SSL_aSRP)) != 0)
        || ((s->s3.tmp.new_cipher->algorithm_mkey & SSL_PSK)) != 0) {
        lu = NULL;
    } else if (lu == NULL) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }

#ifndef OPENSSL_NO_PSK
    if (type & SSL_PSK) {
        size_t len = (s->cert->psk_identity_hint == NULL)
            ? 0
            : strlen(s->cert->psk_identity_hint);

        /*
         * It should not happen that len > PSK_MAX_IDENTITY_LEN - we already
         * checked this when we set the identity hint - but just in case
         */
        if (len > PSK_MAX_IDENTITY_LEN
            || !WPACKET_sub_memcpy_u16(pkt, s->cert->psk_identity_hint,
                len)) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }
    }
#endif

    for (i = 0; i < 4 && r[i] != NULL; i++) {
        unsigned char *binval;
        int res;

#ifndef OPENSSL_NO_SRP
        if ((i == 2) && (type & SSL_kSRP)) {
            res = WPACKET_start_sub_packet_u8(pkt);
        } else
#endif
            res = WPACKET_start_sub_packet_u16(pkt);

        if (!res) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }

        /*-
         * for interoperability with some versions of the Microsoft TLS
         * stack, we need to zero pad the DHE pub key to the same length
         * as the prime
         */
        if ((i == 2) && (type & (SSL_kDHE | SSL_kDHEPSK))) {
            size_t len = BN_num_bytes(r[0]) - BN_num_bytes(r[2]);

            if (len > 0) {
                if (!WPACKET_allocate_bytes(pkt, len, &binval)) {
                    SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                    goto err;
                }
                memset(binval, 0, len);
            }
        }

        if (!WPACKET_allocate_bytes(pkt, BN_num_bytes(r[i]), &binval)
            || !WPACKET_close(pkt)) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }

        BN_bn2bin(r[i], binval);
    }

    if (type & (SSL_kECDHE | SSL_kECDHEPSK)) {
        /*
         * We only support named (not generic) curves. In this situation, the
         * ServerKeyExchange message has: [1 byte CurveType], [2 byte CurveName]
         * [1 byte length of encoded point], followed by the actual encoded
         * point itself
         */
        if (!WPACKET_put_bytes_u8(pkt, NAMED_CURVE_TYPE)
            || !WPACKET_put_bytes_u16(pkt, group_id)
            || !WPACKET_sub_memcpy_u8(pkt, encodedPoint, encodedlen)) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }
        OPENSSL_free(encodedPoint);
        encodedPoint = NULL;
    }

    /* not anonymous */
    if (lu != NULL) {
        EVP_PKEY *pkey = s->s3.tmp.cert->privatekey;
        const EVP_MD *md;
        unsigned char *sigbytes1, *sigbytes2, *tbs;
        size_t siglen = 0, tbslen;

        if (pkey == NULL || !tls1_lookup_md(sctx, lu, &md)) {
            /* Should never happen */
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }
        /* Get length of the parameters we have written above */
        if (!WPACKET_get_length(pkt, &paramlen)) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }
        /* send signature algorithm */
        if (SSL_USE_SIGALGS(s) && !WPACKET_put_bytes_u16(pkt, lu->sigalg)) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }

        if (EVP_DigestSignInit_ex(md_ctx, &pctx,
                md == NULL ? NULL : EVP_MD_get0_name(md),
                sctx->libctx, sctx->propq, pkey,
                NULL)
            <= 0) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }
        if (lu->sig == EVP_PKEY_RSA_PSS) {
            if (EVP_PKEY_CTX_set_rsa_padding(pctx, RSA_PKCS1_PSS_PADDING) <= 0
                || EVP_PKEY_CTX_set_rsa_pss_saltlen(pctx, RSA_PSS_SALTLEN_DIGEST) <= 0) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_EVP_LIB);
                goto err;
            }
        }
        tbslen = construct_key_exchange_tbs(s, &tbs,
            s->init_buf->data + paramoffset,
            paramlen);
        if (tbslen == 0) {
            /* SSLfatal() already called */
            goto err;
        }

        if (EVP_DigestSign(md_ctx, NULL, &siglen, tbs, tbslen) <= 0
            || !WPACKET_sub_reserve_bytes_u16(pkt, siglen, &sigbytes1)
            || EVP_DigestSign(md_ctx, sigbytes1, &siglen, tbs, tbslen) <= 0
            || !WPACKET_sub_allocate_bytes_u16(pkt, siglen, &sigbytes2)
            || sigbytes1 != sigbytes2) {
            OPENSSL_free(tbs);
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }
        OPENSSL_free(tbs);
    }

    ret = CON_FUNC_SUCCESS;
err:
    EVP_PKEY_free(pkdh);
    OPENSSL_free(encodedPoint);
    EVP_MD_CTX_free(md_ctx);
    if (freer) {
        BN_free(r[0]);
        BN_free(r[1]);
        BN_free(r[2]);
        BN_free(r[3]);
    }
    return ret;
}

CON_FUNC_RETURN tls_construct_certificate_request(SSL_CONNECTION *s,
    WPACKET *pkt)
{
    if (SSL_CONNECTION_IS_VERSION13(s)) {
        /* Send random context when doing post-handshake auth */
        if (s->post_handshake_auth == SSL_PHA_REQUEST_PENDING) {
            OPENSSL_free(s->pha_context);
            s->pha_context_len = 32;
            if ((s->pha_context = OPENSSL_malloc(s->pha_context_len)) == NULL) {
                s->pha_context_len = 0;
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                return CON_FUNC_ERROR;
            }
            if (RAND_bytes_ex(SSL_CONNECTION_GET_CTX(s)->libctx,
                    s->pha_context, s->pha_context_len, 0)
                    <= 0
                || !WPACKET_sub_memcpy_u8(pkt, s->pha_context,
                    s->pha_context_len)) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                return CON_FUNC_ERROR;
            }
            /* reset the handshake hash back to just after the ClientFinished */
            if (!tls13_restore_handshake_digest_for_pha(s)) {
                /* SSLfatal() already called */
                return CON_FUNC_ERROR;
            }
        } else {
            if (!WPACKET_put_bytes_u8(pkt, 0)) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                return CON_FUNC_ERROR;
            }
        }

        if (!tls_construct_extensions(s, pkt,
                SSL_EXT_TLS1_3_CERTIFICATE_REQUEST, NULL,
                0)) {
            /* SSLfatal() already called */
            return CON_FUNC_ERROR;
        }
        goto done;
    }

    /* get the list of acceptable cert types */
    if (!WPACKET_start_sub_packet_u8(pkt)
        || !ssl3_get_req_cert_type(s, pkt) || !WPACKET_close(pkt)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return CON_FUNC_ERROR;
    }

    if (SSL_USE_SIGALGS(s)) {
        const uint16_t *psigs;
        size_t nl = tls12_get_psigalgs(s, 1, &psigs);

        if (!WPACKET_start_sub_packet_u16(pkt)
            || !WPACKET_set_flags(pkt, WPACKET_FLAGS_NON_ZERO_LENGTH)
            || !tls12_copy_sigalgs(s, pkt, psigs, nl)
            || !WPACKET_close(pkt)) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            return CON_FUNC_ERROR;
        }
    }

    if (!construct_ca_names(s, get_ca_names(s), pkt)) {
        /* SSLfatal() already called */
        return CON_FUNC_ERROR;
    }

done:
    s->certreqs_sent++;
    s->s3.tmp.cert_request = 1;
    return CON_FUNC_SUCCESS;
}

static int tls_process_cke_psk_preamble(SSL_CONNECTION *s, PACKET *pkt)
{
#ifndef OPENSSL_NO_PSK
    unsigned char psk[PSK_MAX_PSK_LEN];
    size_t psklen;
    PACKET psk_identity;

    if (!PACKET_get_length_prefixed_2(pkt, &psk_identity)) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_MISMATCH);
        return 0;
    }
    if (PACKET_remaining(&psk_identity) > PSK_MAX_IDENTITY_LEN) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_DATA_LENGTH_TOO_LONG);
        return 0;
    }
    if (s->psk_server_callback == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_PSK_NO_SERVER_CB);
        return 0;
    }

    if (!PACKET_strndup(&psk_identity, &s->session->psk_identity)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return 0;
    }

    psklen = s->psk_server_callback(SSL_CONNECTION_GET_USER_SSL(s),
        s->session->psk_identity,
        psk, sizeof(psk));

    if (psklen > PSK_MAX_PSK_LEN) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return 0;
    } else if (psklen == 0) {
        /*
         * PSK related to the given identity not found
         */
        SSLfatal(s, SSL_AD_UNKNOWN_PSK_IDENTITY, SSL_R_PSK_IDENTITY_NOT_FOUND);
        return 0;
    }

    OPENSSL_free(s->s3.tmp.psk);
    s->s3.tmp.psk = OPENSSL_memdup(psk, psklen);
    OPENSSL_cleanse(psk, psklen);

    if (s->s3.tmp.psk == NULL) {
        s->s3.tmp.psklen = 0;
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_CRYPTO_LIB);
        return 0;
    }

    s->s3.tmp.psklen = psklen;

    return 1;
#else
    /* Should never happen */
    SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
    return 0;
#endif
}

static int tls_process_cke_rsa(SSL_CONNECTION *s, PACKET *pkt)
{
    size_t outlen;
    PACKET enc_premaster;
    EVP_PKEY *rsa = NULL;
    unsigned char *rsa_decrypt = NULL;
    int ret = 0;
    EVP_PKEY_CTX *ctx = NULL;
    OSSL_PARAM params[3], *p = params;
    SSL_CTX *sctx = SSL_CONNECTION_GET_CTX(s);

    rsa = s->cert->pkeys[SSL_PKEY_RSA].privatekey;
    if (rsa == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_MISSING_RSA_CERTIFICATE);
        return 0;
    }

    /* pre-standard DTLS omits the length bytes. */
    if (s->version == DTLS1_BAD_VER) {
        enc_premaster = *pkt;
    } else {
        if (!PACKET_get_length_prefixed_2(pkt, &enc_premaster)
            || PACKET_remaining(pkt) != 0) {
            SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_MISMATCH);
            return 0;
        }
    }

    outlen = SSL_MAX_MASTER_KEY_LENGTH;
    rsa_decrypt = OPENSSL_malloc(outlen);
    if (rsa_decrypt == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_CRYPTO_LIB);
        return 0;
    }

    ctx = EVP_PKEY_CTX_new_from_pkey(sctx->libctx, rsa, sctx->propq);
    if (ctx == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_EVP_LIB);
        goto err;
    }

    /*
     * We must not leak whether a decryption failure occurs because of
     * Bleichenbacher's attack on PKCS #1 v1.5 RSA padding (see RFC 2246,
     * section 7.4.7.1). We use the special padding type
     * RSA_PKCS1_WITH_TLS_PADDING to do that. It will automatically decrypt the
     * RSA, check the padding and check that the client version is as expected
     * in the premaster secret. If any of that fails then the function appears
     * to return successfully but with a random result. The call below could
     * still fail if the input is publicly invalid.
     * See https://tools.ietf.org/html/rfc5246#section-7.4.7.1
     */
    if (EVP_PKEY_decrypt_init(ctx) <= 0
        || EVP_PKEY_CTX_set_rsa_padding(ctx, RSA_PKCS1_WITH_TLS_PADDING) <= 0) {
        SSLfatal(s, SSL_AD_DECRYPT_ERROR, SSL_R_DECRYPTION_FAILED);
        goto err;
    }

    *p++ = OSSL_PARAM_construct_uint(OSSL_ASYM_CIPHER_PARAM_TLS_CLIENT_VERSION,
        (unsigned int *)&s->client_version);
    if ((s->options & SSL_OP_TLS_ROLLBACK_BUG) != 0)
        *p++ = OSSL_PARAM_construct_uint(
            OSSL_ASYM_CIPHER_PARAM_TLS_NEGOTIATED_VERSION,
            (unsigned int *)&s->version);
    *p++ = OSSL_PARAM_construct_end();

    if (!EVP_PKEY_CTX_set_params(ctx, params)
        || EVP_PKEY_decrypt(ctx, rsa_decrypt, &outlen,
               PACKET_data(&enc_premaster),
               PACKET_remaining(&enc_premaster))
            <= 0) {
        SSLfatal(s, SSL_AD_DECRYPT_ERROR, SSL_R_DECRYPTION_FAILED);
        goto err;
    }

    /*
     * This test should never fail (otherwise we should have failed above) but
     * we double check anyway.
     */
    if (outlen != SSL_MAX_MASTER_KEY_LENGTH) {
        OPENSSL_cleanse(rsa_decrypt, SSL_MAX_MASTER_KEY_LENGTH);
        SSLfatal(s, SSL_AD_DECRYPT_ERROR, SSL_R_DECRYPTION_FAILED);
        goto err;
    }

    /* Also cleanses rsa_decrypt (on success or failure) */
    if (!ssl_generate_master_secret(s, rsa_decrypt, outlen, 0)) {
        /* SSLfatal() already called */
        goto err;
    }

    ret = 1;
err:
    OPENSSL_free(rsa_decrypt);
    EVP_PKEY_CTX_free(ctx);
    return ret;
}

static int tls_process_cke_dhe(SSL_CONNECTION *s, PACKET *pkt)
{
    EVP_PKEY *skey = NULL;
    unsigned int i;
    const unsigned char *data;
    EVP_PKEY *ckey = NULL;
    int ret = 0;

    if (!PACKET_get_net_2(pkt, &i) || PACKET_remaining(pkt) != i) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_DH_PUBLIC_VALUE_LENGTH_IS_WRONG);
        goto err;
    }
    skey = s->s3.tmp.pkey;
    if (skey == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_MISSING_TMP_DH_KEY);
        goto err;
    }

    if (PACKET_remaining(pkt) == 0L) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_MISSING_TMP_DH_KEY);
        goto err;
    }
    if (!PACKET_get_bytes(pkt, &data, i)) {
        /* We already checked we have enough data */
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }
    ckey = EVP_PKEY_new();
    if (ckey == NULL || EVP_PKEY_copy_parameters(ckey, skey) == 0) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_COPY_PARAMETERS_FAILED);
        goto err;
    }

    if (EVP_PKEY_set1_encoded_public_key(ckey, data, i) <= 0) {
        SSLfatal(s, SSL_AD_ILLEGAL_PARAMETER, SSL_R_BAD_KEY_SHARE);
        goto err;
    }

    if (ssl_derive(s, skey, ckey, 1) == 0) {
        /* SSLfatal() already called */
        goto err;
    }

    ret = 1;
    EVP_PKEY_free(s->s3.tmp.pkey);
    s->s3.tmp.pkey = NULL;
err:
    EVP_PKEY_free(ckey);
    return ret;
}

static int tls_process_cke_ecdhe(SSL_CONNECTION *s, PACKET *pkt)
{
    EVP_PKEY *skey = s->s3.tmp.pkey;
    EVP_PKEY *ckey = NULL;
    int ret = 0;

    if (PACKET_remaining(pkt) == 0L) {
        /* We don't support ECDH client auth */
        SSLfatal(s, SSL_AD_HANDSHAKE_FAILURE, SSL_R_MISSING_TMP_ECDH_KEY);
        goto err;
    } else {
        unsigned int i;
        const unsigned char *data;

        /*
         * Get client's public key from encoded point in the
         * ClientKeyExchange message.
         */

        /*
         * Get encoded point length
         * empty key should be handled here
         */
        if (!PACKET_get_1(pkt, &i) || i == 0 || !PACKET_get_bytes(pkt, &data, i)
            || PACKET_remaining(pkt) != 0) {
            SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_MISMATCH);
            goto err;
        }
        if (skey == NULL) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_MISSING_TMP_ECDH_KEY);
            goto err;
        }

        ckey = EVP_PKEY_new();
        if (ckey == NULL || EVP_PKEY_copy_parameters(ckey, skey) <= 0) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_COPY_PARAMETERS_FAILED);
            goto err;
        }

        if (EVP_PKEY_set1_encoded_public_key(ckey, data, i) <= 0) {
            SSLfatal(s, SSL_AD_ILLEGAL_PARAMETER, SSL_R_BAD_KEY_SHARE);
            goto err;
        }
    }

    if (ssl_derive(s, skey, ckey, 1) == 0) {
        /* SSLfatal() already called */
        goto err;
    }

    ret = 1;
    EVP_PKEY_free(s->s3.tmp.pkey);
    s->s3.tmp.pkey = NULL;
err:
    EVP_PKEY_free(ckey);

    return ret;
}

static int tls_process_cke_srp(SSL_CONNECTION *s, PACKET *pkt)
{
#ifndef OPENSSL_NO_SRP
    unsigned int i;
    const unsigned char *data;

    if (!PACKET_get_net_2(pkt, &i)
        || !PACKET_get_bytes(pkt, &data, i)) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_BAD_SRP_A_LENGTH);
        return 0;
    }
    if ((s->srp_ctx.A = BN_bin2bn(data, i, NULL)) == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_BN_LIB);
        return 0;
    }
    if (BN_ucmp(s->srp_ctx.A, s->srp_ctx.N) >= 0 || BN_is_zero(s->srp_ctx.A)) {
        SSLfatal(s, SSL_AD_ILLEGAL_PARAMETER, SSL_R_BAD_SRP_PARAMETERS);
        return 0;
    }
    OPENSSL_free(s->session->srp_username);
    s->session->srp_username = OPENSSL_strdup(s->srp_ctx.login);
    if (s->session->srp_username == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_CRYPTO_LIB);
        return 0;
    }

    if (!srp_generate_server_master_secret(s)) {
        /* SSLfatal() already called */
        return 0;
    }

    return 1;
#else
    /* Should never happen */
    SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
    return 0;
#endif
}

static int tls_process_cke_gost(SSL_CONNECTION *s, PACKET *pkt)
{
#ifndef OPENSSL_NO_GOST
    EVP_PKEY_CTX *pkey_ctx;
    EVP_PKEY *client_pub_pkey = NULL, *pk = NULL;
    unsigned char premaster_secret[32];
    const unsigned char *start;
    size_t outlen = sizeof(premaster_secret);
    size_t inlen;
    unsigned long alg_a;
    GOST_KX_MESSAGE *pKX = NULL;
    const unsigned char *ptr;
    int ret = 0;
    SSL_CTX *sctx = SSL_CONNECTION_GET_CTX(s);

    /* Get our certificate private key */
    alg_a = s->s3.tmp.new_cipher->algorithm_auth;
    if (alg_a & SSL_aGOST12) {
        /*
         * New GOST ciphersuites have SSL_aGOST01 bit too
         */
        pk = s->cert->pkeys[SSL_PKEY_GOST12_512].privatekey;
        if (pk == NULL) {
            pk = s->cert->pkeys[SSL_PKEY_GOST12_256].privatekey;
        }
        if (pk == NULL) {
            pk = s->cert->pkeys[SSL_PKEY_GOST01].privatekey;
        }
    } else if (alg_a & SSL_aGOST01) {
        pk = s->cert->pkeys[SSL_PKEY_GOST01].privatekey;
    }

    pkey_ctx = EVP_PKEY_CTX_new_from_pkey(sctx->libctx, pk, sctx->propq);
    if (pkey_ctx == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_EVP_LIB);
        return 0;
    }
    if (EVP_PKEY_decrypt_init(pkey_ctx) <= 0) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }
    /*
     * If client certificate is present and is of the same type, maybe
     * use it for key exchange.  Don't mind errors from
     * EVP_PKEY_derive_set_peer, because it is completely valid to use a
     * client certificate for authorization only.
     */
    client_pub_pkey = tls_get_peer_pkey(s);
    if (client_pub_pkey) {
        if (EVP_PKEY_derive_set_peer(pkey_ctx, client_pub_pkey) <= 0)
            ERR_clear_error();
    }

    ptr = PACKET_data(pkt);
    /* Some implementations provide extra data in the opaqueBlob
     * We have nothing to do with this blob so we just skip it */
    pKX = d2i_GOST_KX_MESSAGE(NULL, &ptr, (long)PACKET_remaining(pkt));
    if (pKX == NULL
        || pKX->kxBlob == NULL
        || ASN1_TYPE_get(pKX->kxBlob) != V_ASN1_SEQUENCE) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_DECRYPTION_FAILED);
        goto err;
    }

    if (!PACKET_forward(pkt, ptr - PACKET_data(pkt))) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_DECRYPTION_FAILED);
        goto err;
    }

    if (PACKET_remaining(pkt) != 0) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_DECRYPTION_FAILED);
        goto err;
    }

    inlen = ASN1_STRING_get_length(pKX->kxBlob->value.sequence);
    if (inlen > INT_MAX)
        goto err;

    start = ASN1_STRING_get0_data(pKX->kxBlob->value.sequence);

    if (EVP_PKEY_decrypt(pkey_ctx, premaster_secret, &outlen, start,
            inlen)
        <= 0) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_DECRYPTION_FAILED);
        goto err;
    }
    /* Generate master secret */
    if (!ssl_generate_master_secret(s, premaster_secret, outlen, 0)) {
        /* SSLfatal() already called */
        goto err;
    }
    /* Check if pubkey from client certificate was used */
    if (EVP_PKEY_CTX_ctrl(pkey_ctx, -1, -1, EVP_PKEY_CTRL_PEER_KEY, 2,
            NULL)
        > 0)
        s->statem.no_cert_verify = 1;

    ret = 1;
err:
    EVP_PKEY_CTX_free(pkey_ctx);
    GOST_KX_MESSAGE_free(pKX);
    return ret;
#else
    /* Should never happen */
    SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
    return 0;
#endif
}

static int tls_process_cke_gost18(SSL_CONNECTION *s, PACKET *pkt)
{
#ifndef OPENSSL_NO_GOST
    unsigned char rnd_dgst[32];
    EVP_PKEY_CTX *pkey_ctx = NULL;
    EVP_PKEY *pk = NULL;
    unsigned char premaster_secret[32];
    const unsigned char *start = NULL;
    size_t outlen = sizeof(premaster_secret), inlen = 0;
    int ret = 0;
    int cipher_nid = ossl_gost18_cke_cipher_nid(s);
    SSL_CTX *sctx = SSL_CONNECTION_GET_CTX(s);

    if (cipher_nid == NID_undef) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return 0;
    }

    if (ossl_gost_ukm(s, rnd_dgst) <= 0) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }

    /* Get our certificate private key */
    pk = s->cert->pkeys[SSL_PKEY_GOST12_512].privatekey != NULL ? s->cert->pkeys[SSL_PKEY_GOST12_512].privatekey : s->cert->pkeys[SSL_PKEY_GOST12_256].privatekey;
    if (pk == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_BAD_HANDSHAKE_STATE);
        goto err;
    }

    pkey_ctx = EVP_PKEY_CTX_new_from_pkey(sctx->libctx, pk, sctx->propq);
    if (pkey_ctx == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_EVP_LIB);
        goto err;
    }
    if (EVP_PKEY_decrypt_init(pkey_ctx) <= 0) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }

    if (EVP_PKEY_CTX_ctrl(pkey_ctx, -1, EVP_PKEY_OP_DECRYPT,
            EVP_PKEY_CTRL_SET_IV, 32, rnd_dgst)
        <= 0) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_LIBRARY_BUG);
        goto err;
    }

    if (EVP_PKEY_CTX_ctrl(pkey_ctx, -1, EVP_PKEY_OP_DECRYPT,
            EVP_PKEY_CTRL_CIPHER, cipher_nid, NULL)
        <= 0) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_LIBRARY_BUG);
        goto err;
    }
    inlen = PACKET_remaining(pkt);
    start = PACKET_data(pkt);

    if (EVP_PKEY_decrypt(pkey_ctx, premaster_secret, &outlen, start, inlen) <= 0) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_DECRYPTION_FAILED);
        goto err;
    }
    /* Generate master secret */
    if (!ssl_generate_master_secret(s, premaster_secret, outlen, 0)) {
        /* SSLfatal() already called */
        goto err;
    }
    ret = 1;

err:
    EVP_PKEY_CTX_free(pkey_ctx);
    return ret;
#else
    /* Should never happen */
    SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
    return 0;
#endif
}

MSG_PROCESS_RETURN tls_process_client_key_exchange(SSL_CONNECTION *s,
    PACKET *pkt)
{
    unsigned long alg_k;

    alg_k = s->s3.tmp.new_cipher->algorithm_mkey;

    /* For PSK parse and retrieve identity, obtain PSK key */
    if ((alg_k & SSL_PSK) && !tls_process_cke_psk_preamble(s, pkt)) {
        /* SSLfatal() already called */
        goto err;
    }

    if (alg_k & SSL_kPSK) {
        /* Identity extracted earlier: should be nothing left */
        if (PACKET_remaining(pkt) != 0) {
            SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_MISMATCH);
            goto err;
        }
        /* PSK handled by ssl_generate_master_secret */
        if (!ssl_generate_master_secret(s, NULL, 0, 0)) {
            /* SSLfatal() already called */
            goto err;
        }
    } else if (alg_k & (SSL_kRSA | SSL_kRSAPSK)) {
        if (!tls_process_cke_rsa(s, pkt)) {
            /* SSLfatal() already called */
            goto err;
        }
    } else if (alg_k & (SSL_kDHE | SSL_kDHEPSK)) {
        if (!tls_process_cke_dhe(s, pkt)) {
            /* SSLfatal() already called */
            goto err;
        }
    } else if (alg_k & (SSL_kECDHE | SSL_kECDHEPSK)) {
        if (!tls_process_cke_ecdhe(s, pkt)) {
            /* SSLfatal() already called */
            goto err;
        }
    } else if (alg_k & SSL_kSRP) {
        if (!tls_process_cke_srp(s, pkt)) {
            /* SSLfatal() already called */
            goto err;
        }
    } else if (alg_k & SSL_kGOST) {
        if (!tls_process_cke_gost(s, pkt)) {
            /* SSLfatal() already called */
            goto err;
        }
    } else if (alg_k & SSL_kGOST18) {
        if (!tls_process_cke_gost18(s, pkt)) {
            /* SSLfatal() already called */
            goto err;
        }
    } else {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_UNKNOWN_CIPHER_TYPE);
        goto err;
    }

    return MSG_PROCESS_CONTINUE_PROCESSING;
err:
#ifndef OPENSSL_NO_PSK
    OPENSSL_clear_free(s->s3.tmp.psk, s->s3.tmp.psklen);
    s->s3.tmp.psk = NULL;
    s->s3.tmp.psklen = 0;
#endif
    return MSG_PROCESS_ERROR;
}

WORK_STATE tls_post_process_client_key_exchange(SSL_CONNECTION *s,
    WORK_STATE wst)
{
#ifndef OPENSSL_NO_SCTP
    if (wst == WORK_MORE_A) {
        /*
         * Before exporting the SCTP auth key we check if DTLSv1.3 has been
         * negotiated which is not supported.
         * Refer to draft-tuexen-tsvwg-rfc6083-bis-04 for more info.
         */
        if (SSL_CONNECTION_IS_DTLS(s) && !SSL_CONNECTION_IS_DTLS13(s)) {
            unsigned char sctpauthkey[64];
            char labelbuffer[sizeof(DTLS1_SCTP_AUTH_LABEL)];
            size_t labellen;
            /*
             * Add new shared key for SCTP-Auth, will be ignored if no SCTP
             * used.
             */
            memcpy(labelbuffer, DTLS1_SCTP_AUTH_LABEL,
                sizeof(DTLS1_SCTP_AUTH_LABEL));

            /* Don't include the terminating zero. */
            labellen = sizeof(labelbuffer) - 1;
            if (s->mode & SSL_MODE_DTLS_SCTP_LABEL_LENGTH_BUG)
                labellen += 1;

            if (SSL_export_keying_material(SSL_CONNECTION_GET_SSL(s),
                    sctpauthkey,
                    sizeof(sctpauthkey), labelbuffer,
                    labellen, NULL, 0,
                    0)
                <= 0) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                return WORK_ERROR;
            }

            BIO_ctrl(s->wbio, BIO_CTRL_DGRAM_SCTP_ADD_AUTH_KEY,
                sizeof(sctpauthkey), sctpauthkey);
        }
    }
#endif

    if (s->statem.no_cert_verify || !received_client_cert(s)) {
        /*
         * No certificate verify or no peer certificate so we no longer need
         * the handshake_buffer
         */
        if (!ssl3_digest_cached_records(s, 0)) {
            /* SSLfatal() already called */
            return WORK_ERROR;
        }
        return WORK_FINISHED_CONTINUE;
    } else {
        if (!s->s3.handshake_buffer) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            return WORK_ERROR;
        }
        /*
         * For sigalgs freeze the handshake buffer. If we support
         * extms we've done this already so this is a no-op
         */
        if (!ssl3_digest_cached_records(s, 1)) {
            /* SSLfatal() already called */
            return WORK_ERROR;
        }
    }

    return WORK_FINISHED_CONTINUE;
}

static void tls_clear_pending_client_identity(SSL_CONNECTION *sc)
{
    OSSL_STACK_OF_X509_free(sc->s3.tmp.pending_peer_chain);
    sc->s3.tmp.pending_peer_chain = NULL;
    EVP_PKEY_free(sc->s3.tmp.pending_peer_rpk);
    sc->s3.tmp.pending_peer_rpk = NULL;
}

/*
 * Clear old verification state before verifying fresh credentials, or after
 * accepting an empty initial Certificate response. Empty PHA responses retain
 * the previous state. Do not clear results produced by the new verification.
 */
static void tls_clear_client_verification_state(SSL_CONNECTION *sc, long verify_result)
{
    OSSL_STACK_OF_X509_free(sc->verified_chain);
    sc->verified_chain = NULL;
    X509_VERIFY_PARAM_move_peername(sc->param, NULL);
    sc->dane.mdpth = -1;
    sc->dane.pdpth = -1;
    X509_free(sc->dane.mcert);
    sc->dane.mcert = NULL;
    sc->dane.mtlsa = NULL;
    sc->verify_result = verify_result;
}

MSG_PROCESS_RETURN tls_process_client_rpk(SSL_CONNECTION *sc, PACKET *pkt)
{
    EVP_PKEY *peer_rpk = NULL;

    if (!tls_process_rpk(sc, pkt, &peer_rpk)) {
        /* SSLfatal already called */
        return MSG_PROCESS_ERROR;
    }

    /* Stash the parsed RPK; verification runs in the post-process step. */
    tls_clear_pending_client_identity(sc);
    sc->s3.tmp.pending_peer_rpk = peer_rpk;
    if (peer_rpk != NULL)
        tls_clear_client_verification_state(sc, X509_V_ERR_UNSPECIFIED);

    return MSG_PROCESS_CONTINUE_PROCESSING;
}

/* Verify the parked RPK; may pause via SSL_set_retry_verify(). */
static WORK_STATE tls_post_process_client_rpk(SSL_CONNECTION *sc,
    WORK_STATE wst)
{
    EVP_PKEY *peer_rpk = sc->s3.tmp.pending_peer_rpk;
    SSL_SESSION *new_sess = NULL;

    (void)wst;

    if (SSL_CONNECTION_IS_VERSION13(sc))
        sc->statem.no_cert_verify = peer_rpk == NULL;

    if (peer_rpk == NULL) {
        if ((sc->verify_mode & SSL_VERIFY_FAIL_IF_NO_PEER_CERT)
            && (sc->verify_mode & SSL_VERIFY_PEER)) {
            SSLfatal(sc, SSL_AD_CERTIFICATE_REQUIRED,
                SSL_R_PEER_DID_NOT_RETURN_A_CERTIFICATE);
            goto err;
        }
    } else {
        int v_ok;

        if (sc->rwstate == SSL_RETRY_VERIFY)
            sc->rwstate = SSL_NOTHING;
        v_ok = ssl_verify_rpk(sc, peer_rpk);
        if (v_ok > 0 && sc->rwstate == SSL_RETRY_VERIFY) {
            /* The verify callback asked to pause; resume here on retry. */
            return WORK_MORE_A;
        }
        if (v_ok <= 0) {
            SSLfatal(sc, ssl_x509err2alert(sc->verify_result),
                SSL_R_CERTIFICATE_VERIFY_FAILED);
            goto err;
        }
    }

    /*
     * Sessions must be immutable once they go into the session cache. Otherwise
     * we can get multi-thread problems. Therefore we don't "update" sessions,
     * we replace them with a duplicate. Here, we need to do this every time
     * a PHA response is accepted, even if empty, because refreshed tickets
     * will update the session's key and ID.
     */
    if (sc->post_handshake_auth == SSL_PHA_REQUESTED) {
        if ((new_sess = ssl_session_dup(sc->session, 0)) == NULL) {
            SSLfatal(sc, SSL_AD_INTERNAL_ERROR, ERR_R_MALLOC_FAILURE);
            goto err;
        }

        SSL_SESSION_free(sc->session);
        sc->session = new_sess;
    }

    if (peer_rpk != NULL || sc->post_handshake_auth != SSL_PHA_REQUESTED) {
        if (peer_rpk == NULL)
            tls_clear_client_verification_state(sc, X509_V_OK);
        ossl_session_set0_peer(sc->session, NULL, peer_rpk, sc->verify_result);
        sc->s3.tmp.pending_peer_rpk = NULL;
    }

    /*
     * Freeze the handshake buffer. For <TLS1.3 we do this after the CKE
     * message
     */
    if (SSL_CONNECTION_IS_VERSION13(sc)) {
        if (!ssl3_digest_cached_records(sc, 1)) {
            /* SSLfatal() already called */
            goto err;
        }

        /* Save the current hash state for when we receive the CertificateVerify */
        if (!ssl_handshake_hash(sc, sc->cert_verify_hash,
                sizeof(sc->cert_verify_hash),
                &sc->cert_verify_hash_len)) {
            /* SSLfatal() already called */
            goto err;
        }

        /* resend session tickets */
        sc->sent_tickets = 0;
    }

    return WORK_FINISHED_CONTINUE;

err:
    tls_clear_pending_client_identity(sc);
    return WORK_ERROR;
}

MSG_PROCESS_RETURN tls_process_client_certificate(SSL_CONNECTION *s,
    PACKET *pkt)
{
    MSG_PROCESS_RETURN ret = MSG_PROCESS_ERROR;
    X509 *x = NULL;
    unsigned long l;
    const unsigned char *certstart, *certbytes;
    STACK_OF(X509) *sk = NULL;
    PACKET spkt, context;
    size_t chainidx;
    SSL_CTX *sctx = SSL_CONNECTION_GET_CTX(s);

    /*
     * To get this far we must have read encrypted data from the client. We no
     * longer tolerate unencrypted alerts. This is ignored if less than TLSv1.3
     */
    if (s->rlayer.rrlmethod->set_plain_alerts != NULL)
        s->rlayer.rrlmethod->set_plain_alerts(s->rlayer.rrl, 0);

    if (s->ext.client_cert_type == TLSEXT_cert_type_rpk)
        return tls_process_client_rpk(s, pkt);

    if (s->ext.client_cert_type != TLSEXT_cert_type_x509) {
        SSLfatal(s, SSL_AD_UNSUPPORTED_CERTIFICATE,
            SSL_R_UNKNOWN_CERTIFICATE_TYPE);
        goto err;
    }

    if ((sk = sk_X509_new_null()) == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_CRYPTO_LIB);
        goto err;
    }

    if (SSL_CONNECTION_IS_VERSION13(s)
        && (!PACKET_get_length_prefixed_1(pkt, &context)
            || (s->pha_context == NULL && PACKET_remaining(&context) != 0)
            || (s->pha_context != NULL
                && !PACKET_equal(&context, s->pha_context,
                    s->pha_context_len)))) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_INVALID_CONTEXT);
        goto err;
    }

    if (!PACKET_get_length_prefixed_3(pkt, &spkt)
        || PACKET_remaining(pkt) != 0) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_MISMATCH);
        goto err;
    }

    for (chainidx = 0; PACKET_remaining(&spkt) > 0; chainidx++) {
        if (!PACKET_get_net_3(&spkt, &l)
            || !PACKET_get_bytes(&spkt, &certbytes, l)) {
            SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_CERT_LENGTH_MISMATCH);
            goto err;
        }

        certstart = certbytes;
        x = X509_new_ex(sctx->libctx, sctx->propq);
        if (x == NULL) {
            SSLfatal(s, SSL_AD_DECODE_ERROR, ERR_R_X509_LIB);
            goto err;
        }
        if (d2i_X509(&x, (const unsigned char **)&certbytes, l) == NULL) {
            SSLfatal(s, SSL_AD_DECODE_ERROR, ERR_R_ASN1_LIB);
            goto err;
        }

        if (certbytes != (certstart + l)) {
            SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_CERT_LENGTH_MISMATCH);
            goto err;
        }

        if (SSL_CONNECTION_IS_VERSION13(s)) {
            RAW_EXTENSION *rawexts = NULL;
            PACKET extensions;

            if (!PACKET_get_length_prefixed_2(&spkt, &extensions)) {
                SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_BAD_LENGTH);
                goto err;
            }
            if (!tls_collect_extensions(s, &extensions,
                    SSL_EXT_TLS1_3_CERTIFICATE, &rawexts,
                    NULL, chainidx == 0)
                || !tls_parse_all_extensions(s, SSL_EXT_TLS1_3_CERTIFICATE,
                    rawexts, x, chainidx,
                    PACKET_remaining(&spkt) == 0)) {
                OPENSSL_free(rawexts);
                goto err;
            }
            OPENSSL_free(rawexts);
        }

        if (!sk_X509_push(sk, x)) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_CRYPTO_LIB);
            goto err;
        }
        x = NULL;
    }

    /*
     * Stash the parsed chain so that tls_post_process_client_certificate() can
     * run verification and may pause the handshake via SSL_set_retry_verify().
     */
    tls_clear_pending_client_identity(s);
    s->s3.tmp.pending_peer_chain = sk;
    if (sk_X509_num(sk) > 0)
        tls_clear_client_verification_state(s, X509_V_ERR_UNSPECIFIED);

    return MSG_PROCESS_CONTINUE_PROCESSING;

err:
    X509_free(x);
    OSSL_STACK_OF_X509_free(sk);
    return ret;
}

/*
 * Verify the parked chain from tls_process_client_certificate() and finalize
 * the peer cert / TLS 1.3 handshake-hash bookkeeping.
 * Allows the verify callback to defer via SSL_set_retry_verify(), in which
 * case we return WORK_MORE_A and the state machine re-enters this function
 * once the application has supplied a verdict.
 */
WORK_STATE tls_post_process_client_certificate(SSL_CONNECTION *s,
    WORK_STATE wst)
{
    STACK_OF(X509) *sk;
    SSL_SESSION *new_sess = NULL;
    EVP_PKEY *pkey;
    int has_cert, i;

    if (s->ext.client_cert_type == TLSEXT_cert_type_rpk)
        return tls_post_process_client_rpk(s, wst);

    sk = s->s3.tmp.pending_peer_chain;
    (void)wst;

    has_cert = sk != NULL && sk_X509_num(sk) > 0;
    if (SSL_CONNECTION_IS_VERSION13(s))
        s->statem.no_cert_verify = !has_cert;
    if (!has_cert) {
        /* Fail only if we required a certificate */
        if ((s->verify_mode & SSL_VERIFY_PEER)
            && (s->verify_mode & SSL_VERIFY_FAIL_IF_NO_PEER_CERT)) {
            SSLfatal(s, SSL_AD_CERTIFICATE_REQUIRED,
                SSL_R_PEER_DID_NOT_RETURN_A_CERTIFICATE);
            goto err;
        }

        /* No client certificate so digest cached records */
        if (s->s3.handshake_buffer && !ssl3_digest_cached_records(s, 0)) {
            /* SSLfatal() already called */
            goto err;
        }
    } else {
        if (s->rwstate == SSL_RETRY_VERIFY)
            s->rwstate = SSL_NOTHING;
        i = ssl_verify_cert_chain(s, sk);
        if (i > 0 && s->rwstate == SSL_RETRY_VERIFY) {
            /*
             * The application's verify callback asked us to pause via
             * SSL_set_retry_verify(); SSL_do_handshake() will return
             * SSL_ERROR_WANT_RETRY_VERIFY and the state machine resumes here
             * once the callback is invoked again.
             */
            return WORK_MORE_A;
        }
        if (i <= 0) {
            SSLfatal(s, ssl_x509err2alert(s->verify_result),
                SSL_R_CERTIFICATE_VERIFY_FAILED);
            goto err;
        }
        pkey = X509_get0_pubkey(sk_X509_value(sk, 0));
        if (pkey == NULL) {
            SSLfatal(s, SSL_AD_HANDSHAKE_FAILURE,
                SSL_R_UNKNOWN_CERTIFICATE_TYPE);
            goto err;
        }
    }

    /*
     * Sessions must be immutable once they go into the session cache. Otherwise
     * we can get multi-thread problems. Therefore we don't "update" sessions,
     * we replace them with a duplicate. Here, we need to do this every time
     * a PHA response is accepted, even if empty, because refreshed tickets
     * will update the session's key and ID.
     */
    if (s->post_handshake_auth == SSL_PHA_REQUESTED) {
        if ((new_sess = ssl_session_dup(s->session, 0)) == 0) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_SSL_LIB);
            goto err;
        }

        SSL_SESSION_free(s->session);
        s->session = new_sess;
    }

    if (!has_cert) {
        tls_clear_pending_client_identity(s);
        sk = NULL;
        if (s->post_handshake_auth != SSL_PHA_REQUESTED)
            tls_clear_client_verification_state(s, X509_V_OK);
    }
    if (has_cert || s->post_handshake_auth != SSL_PHA_REQUESTED) {
        ossl_session_set0_peer(s->session, sk, NULL, s->verify_result);
        s->s3.tmp.pending_peer_chain = NULL;
    }

    /*
     * Freeze the handshake buffer. For <TLS1.3 we do this after the CKE
     * message
     */
    if (SSL_CONNECTION_IS_VERSION13(s) && !ssl3_digest_cached_records(s, 1)) {
        /* SSLfatal() already called */
        goto err;
    }

    /* Save the current hash state for when we receive the CertificateVerify */
    if (SSL_CONNECTION_IS_VERSION13(s)) {
        if (!ssl_handshake_hash(s, s->cert_verify_hash,
                sizeof(s->cert_verify_hash),
                &s->cert_verify_hash_len)) {
            /* SSLfatal() already called */
            goto err;
        }

        /* Resend session tickets */
        s->sent_tickets = 0;
    }

    return WORK_FINISHED_CONTINUE;

err:
    tls_clear_pending_client_identity(s);
    return WORK_ERROR;
}

#ifndef OPENSSL_NO_COMP_ALG
MSG_PROCESS_RETURN tls_process_client_compressed_certificate(SSL_CONNECTION *sc, PACKET *pkt)
{
    MSG_PROCESS_RETURN ret = MSG_PROCESS_ERROR;
    PACKET tmppkt;
    BUF_MEM *buf = BUF_MEM_new();

    if (tls13_process_compressed_certificate(sc, pkt, &tmppkt, buf) != MSG_PROCESS_ERROR)
        ret = tls_process_client_certificate(sc, &tmppkt);

    BUF_MEM_free(buf);
    return ret;
}
#endif

CON_FUNC_RETURN tls_construct_server_certificate(SSL_CONNECTION *s, WPACKET *pkt)
{
    CERT_PKEY *cpk = s->s3.tmp.cert;

    if (cpk == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return CON_FUNC_ERROR;
    }

    /*
     * In TLSv1.3 the certificate chain is always preceded by a 0 length context
     * for the server Certificate message
     */
    if (SSL_CONNECTION_IS_VERSION13(s) && !WPACKET_put_bytes_u8(pkt, 0)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return CON_FUNC_ERROR;
    }
    switch (s->ext.server_cert_type) {
    case TLSEXT_cert_type_rpk:
        if (!tls_output_rpk(s, pkt, cpk)) {
            /* SSLfatal() already called */
            return 0;
        }
        break;
    case TLSEXT_cert_type_x509:
        if (!ssl3_output_cert_chain(s, pkt, cpk, 0)) {
            /* SSLfatal() already called */
            return 0;
        }
        break;
    default:
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return 0;
    }

    return CON_FUNC_SUCCESS;
}

#ifndef OPENSSL_NO_COMP_ALG
CON_FUNC_RETURN tls_construct_server_compressed_certificate(SSL_CONNECTION *sc, WPACKET *pkt)
{
    int alg = get_compressed_certificate_alg(sc);
    OSSL_COMP_CERT *cc = sc->s3.tmp.cert->comp_cert[alg];

    if (!ossl_assert(cc != NULL)) {
        SSLfatal(sc, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return 0;
    }
    /*
     * Server can't compress on-demand
     * Use pre-compressed certificate
     */
    if (!WPACKET_put_bytes_u16(pkt, alg)
        || !WPACKET_put_bytes_u24(pkt, cc->orig_len)
        || !WPACKET_start_sub_packet_u24(pkt)
        || !WPACKET_memcpy(pkt, cc->data, cc->len)
        || !WPACKET_close(pkt)) {
        SSLfatal(sc, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return 0;
    }

    sc->s3.tmp.cert->cert_comp_used++;
    return 1;
}
#endif

static int create_ticket_prequel(SSL_CONNECTION *s, WPACKET *pkt,
    uint32_t age_add, unsigned char *tick_nonce)
{
    uint32_t timeout = (uint32_t)ossl_time2seconds(s->session->timeout);

    /*
     * Ticket lifetime hint:
     * In TLSv1.3 we reset the "time" field above, and always specify the
     * timeout, limited to a 1 week period per RFC9846.
     * For TLSv1.2 this is advisory only and we leave this unspecified for
     * resumed session (for simplicity).
     */
#define ONE_WEEK_SEC (7 * 24 * 60 * 60)

    if (SSL_CONNECTION_IS_VERSION13(s)) {
        if (ossl_time_compare(s->session->timeout,
                ossl_seconds2time(ONE_WEEK_SEC))
            > 0)
            timeout = ONE_WEEK_SEC;
    } else if (s->hit)
        timeout = 0;

    if (!WPACKET_put_bytes_u32(pkt, timeout)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return 0;
    }

    if (SSL_CONNECTION_IS_VERSION13(s)) {
        if (!WPACKET_put_bytes_u32(pkt, age_add)
            || !WPACKET_sub_memcpy_u8(pkt, tick_nonce, TICKET_NONCE_SIZE)) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            return 0;
        }
    }

    /* Start the sub-packet for the actual ticket data */
    if (!WPACKET_start_sub_packet_u16(pkt)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return 0;
    }

    return 1;
}

static CON_FUNC_RETURN construct_stateless_ticket(SSL_CONNECTION *s,
    WPACKET *pkt,
    uint32_t age_add,
    unsigned char *tick_nonce)
{
    unsigned char *senc = NULL;
    EVP_CIPHER_CTX *ctx = NULL;
    SSL_HMAC hctx, *constructed_hctx = NULL;
    unsigned char *p, *encdata1, *encdata2, *macdata1, *macdata2;
    const unsigned char *const_p;
    int len, slen_full, slen, lenfinal;
    SSL_SESSION *sess;
    size_t hlen;
    SSL_CTX *tctx = s->session_ctx;
    unsigned char iv[EVP_MAX_IV_LENGTH];
    unsigned char key_name[TLSEXT_KEYNAME_LENGTH];
    int iv_len;
    CON_FUNC_RETURN ok = CON_FUNC_ERROR;
    size_t macoffset, macendoffset;
    SSL *ssl = SSL_CONNECTION_GET_USER_SSL(s);
    SSL_CTX *sctx = SSL_CONNECTION_GET_CTX(s);

    /* get session encoding length */
    slen_full = i2d_SSL_SESSION(s->session, NULL);
    /*
     * Some length values are 16 bits, so forget it if session is too
     * long
     */
    if (slen_full == 0 || slen_full > 0xFF00) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }
    senc = OPENSSL_malloc(slen_full);
    if (senc == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_CRYPTO_LIB);
        goto err;
    }

    ctx = EVP_CIPHER_CTX_new();
    if (ctx == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_EVP_LIB);
        goto err;
    }
    if ((constructed_hctx = ssl_hmac_construct(tctx, &hctx)) == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_SSL_LIB);
        goto err;
    }

    p = senc;
    if (!i2d_SSL_SESSION(s->session, &p)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }

    /*
     * create a fresh copy (not shared with other threads) to clean up
     */
    const_p = senc;
    sess = d2i_SSL_SESSION_ex(NULL, &const_p, slen_full, sctx->libctx,
        sctx->propq);
    if (sess == NULL) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }

    slen = i2d_SSL_SESSION(sess, NULL);
    if (slen == 0 || slen > slen_full) {
        /* shouldn't ever happen */
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        SSL_SESSION_free(sess);
        goto err;
    }
    p = senc;
    if (!i2d_SSL_SESSION(sess, &p)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        SSL_SESSION_free(sess);
        goto err;
    }
    SSL_SESSION_free(sess);

    /*
     * Initialize HMAC and cipher contexts. If callback present it does
     * all the work otherwise use generated values from parent ctx.
     */
#ifndef OPENSSL_NO_DEPRECATED_3_0
    if (tctx->ext.ticket_key_evp_cb != NULL || tctx->ext.ticket_key_cb != NULL)
#else
    if (tctx->ext.ticket_key_evp_cb != NULL)
#endif
    {
        int ret = 0;

        if (tctx->ext.ticket_key_evp_cb != NULL)
            ret = tctx->ext.ticket_key_evp_cb(ssl, key_name, iv, ctx,
                ssl_hmac_get0_EVP_MAC_CTX(&hctx),
                1);
#ifndef OPENSSL_NO_DEPRECATED_3_0
        else if (tctx->ext.ticket_key_cb != NULL)
            /* if 0 is returned, write an empty ticket */
            ret = tctx->ext.ticket_key_cb(ssl, key_name, iv, ctx,
                ssl_hmac_get0_HMAC_CTX(&hctx), 1);
#endif

        if (ret == 0) {
            /*
             * In TLSv1.2 we construct a 0 length ticket. In TLSv1.3 a 0
             * length ticket is not allowed so we abort construction of the
             * ticket
             */
            if (SSL_CONNECTION_IS_VERSION13(s)) {
                ok = CON_FUNC_DONT_SEND;
                goto err;
            }
            /* Put timeout and length */
            if (!WPACKET_put_bytes_u32(pkt, 0)
                || !WPACKET_put_bytes_u16(pkt, 0)) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
                goto err;
            }
            OPENSSL_free(senc);
            EVP_CIPHER_CTX_free(ctx);
            ssl_hmac_destruct(constructed_hctx);
            return CON_FUNC_SUCCESS;
        }
        if (ret < 0) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, SSL_R_CALLBACK_FAILED);
            goto err;
        }
        iv_len = EVP_CIPHER_CTX_get_iv_length(ctx);
        if (iv_len < 0) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }
    } else {
        iv_len = EVP_CIPHER_get_iv_length(sctx->tktenc);
        if (iv_len < 0
            || RAND_bytes_ex(sctx->libctx, iv, iv_len, 0) <= 0
            || !EVP_EncryptInit_ex(ctx, sctx->tktenc, NULL,
                tctx->ext.secure->tick_aes_key, iv)
            || !ssl_hmac_init(&hctx, tctx->ext.secure->tick_hmac_key,
                sizeof(tctx->ext.secure->tick_hmac_key),
                "SHA256")) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }
        memcpy(key_name, tctx->ext.tick_key_name,
            sizeof(tctx->ext.tick_key_name));
    }

    if (!create_ticket_prequel(s, pkt, age_add, tick_nonce)) {
        /* SSLfatal() already called */
        goto err;
    }

    if (!WPACKET_get_total_written(pkt, &macoffset)
        /* Output key name */
        || !WPACKET_memcpy(pkt, key_name, sizeof(key_name))
        /* output IV */
        || !WPACKET_memcpy(pkt, iv, iv_len)
        || !WPACKET_reserve_bytes(pkt, slen + EVP_MAX_BLOCK_LENGTH,
            &encdata1)
        /* Encrypt session data */
        || !EVP_EncryptUpdate(ctx, encdata1, &len, senc, slen)
        || !WPACKET_allocate_bytes(pkt, len, &encdata2)
        || encdata1 != encdata2
        || !EVP_EncryptFinal(ctx, encdata1 + len, &lenfinal)
        || !WPACKET_allocate_bytes(pkt, lenfinal, &encdata2)
        || encdata1 + len != encdata2
        || len + lenfinal > slen + EVP_MAX_BLOCK_LENGTH
        || !WPACKET_get_total_written(pkt, &macendoffset)
        || !ssl_hmac_update(&hctx,
            (unsigned char *)s->init_buf->data + macoffset,
            macendoffset - macoffset)
        || !WPACKET_reserve_bytes(pkt, EVP_MAX_MD_SIZE, &macdata1)
        || !ssl_hmac_final(&hctx, macdata1, &hlen, EVP_MAX_MD_SIZE)
        || hlen > EVP_MAX_MD_SIZE
        || !WPACKET_allocate_bytes(pkt, hlen, &macdata2)
        || macdata1 != macdata2) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }

    /* Close the sub-packet created by create_ticket_prequel() */
    if (!WPACKET_close(pkt)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }

    ok = CON_FUNC_SUCCESS;
err:
    OPENSSL_free(senc);
    EVP_CIPHER_CTX_free(ctx);
    ssl_hmac_destruct(constructed_hctx);
    return ok;
}

static int construct_stateful_ticket(SSL_CONNECTION *s, WPACKET *pkt,
    uint32_t age_add,
    unsigned char *tick_nonce)
{
    if (!create_ticket_prequel(s, pkt, age_add, tick_nonce)) {
        /* SSLfatal() already called */
        return 0;
    }

    if (!WPACKET_memcpy(pkt, s->session->session_id,
            s->session->session_id_length)
        || !WPACKET_close(pkt)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return 0;
    }

    return 1;
}

static void tls_update_ticket_counts(SSL_CONNECTION *s)
{
    /*
     * Increment both |sent_tickets| and |next_ticket_nonce|. |sent_tickets|
     * gets reset to 0 if we send more tickets following a post-handshake
     * auth, but |next_ticket_nonce| does not.  If we're sending extra
     * tickets, decrement the count of pending extra tickets.
     */
    s->sent_tickets++;
    s->next_ticket_nonce++;
    if (s->ext.extra_tickets_expected > 0)
        s->ext.extra_tickets_expected--;
}

CON_FUNC_RETURN tls_construct_new_session_ticket(SSL_CONNECTION *s, WPACKET *pkt)
{
    SSL_CTX *tctx = s->session_ctx;
    unsigned char tick_nonce[TICKET_NONCE_SIZE];
    union {
        unsigned char age_add_c[sizeof(uint32_t)];
        uint32_t age_add;
    } age_add_u;
    CON_FUNC_RETURN ret = CON_FUNC_ERROR;

    age_add_u.age_add = 0;

    if (SSL_CONNECTION_IS_VERSION13(s)) {
        size_t i, hashlen;
        uint64_t nonce;
        /* ASCII: "resumption", in hex for EBCDIC compatibility */
        static const unsigned char nonce_label[] = { 0x72, 0x65, 0x73, 0x75, 0x6D,
            0x70, 0x74, 0x69, 0x6F, 0x6E };
        const EVP_MD *md = ssl_handshake_md(s);
        int hashleni = EVP_MD_get_size(md);

        /* Ensure cast to size_t is safe */
        if (!ossl_assert(hashleni > 0)) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }
        hashlen = (size_t)hashleni;

        /*
         * If we already sent one NewSessionTicket, or we resumed then
         * s->session may already be in a cache and so we must not modify it.
         * Instead we need to take a copy of it and modify that.
         */
        if (s->sent_tickets != 0 || s->hit) {
            SSL_SESSION *new_sess = ssl_session_dup(s->session, 0);

            if (new_sess == NULL) {
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_SSL_LIB);
                goto err;
            }

            SSL_SESSION_free(s->session);
            s->session = new_sess;
        }

        if (!ssl_generate_session_id(s, s->session)) {
            /* SSLfatal() already called */
            goto err;
        }
        if (RAND_bytes_ex(SSL_CONNECTION_GET_CTX(s)->libctx,
                age_add_u.age_add_c, sizeof(age_add_u), 0)
            <= 0) {
            SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
            goto err;
        }
        s->session->ext.tick_age_add = age_add_u.age_add;

        nonce = s->next_ticket_nonce;
        for (i = TICKET_NONCE_SIZE; i > 0; i--) {
            tick_nonce[i - 1] = (unsigned char)(nonce & 0xff);
            nonce >>= 8;
        }

        if (!tls13_hkdf_expand(s, md, s->resumption_master_secret,
                nonce_label,
                sizeof(nonce_label),
                tick_nonce,
                TICKET_NONCE_SIZE,
                s->session->master_key,
                hashlen, 1)) {
            /* SSLfatal() already called */
            goto err;
        }
        s->session->master_key_length = hashlen;

        s->session->time = ossl_time_now();
        ssl_session_calculate_timeout(s->session);
        if (s->s3.alpn_selected != NULL) {
            OPENSSL_free(s->session->ext.alpn_selected);
            s->session->ext.alpn_selected = OPENSSL_memdup(s->s3.alpn_selected, s->s3.alpn_selected_len);
            if (s->session->ext.alpn_selected == NULL) {
                s->session->ext.alpn_selected_len = 0;
                SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_CRYPTO_LIB);
                goto err;
            }
            s->session->ext.alpn_selected_len = s->s3.alpn_selected_len;
        } else {
            /*
             * No ALPN was negotiated on this handshake. If we resumed a
             * session that had previously negotiated ALPN, the stale value
             * must be cleared from the (copied) session before it is stored
             * in the new ticket. Otherwise a subsequent 0-RTT attempt using
             * that ticket would incorrectly assume an ALPN protocol had been
             * negotiated. See tls_handle_alpn().
             */
            OPENSSL_free(s->session->ext.alpn_selected);
            s->session->ext.alpn_selected = NULL;
            s->session->ext.alpn_selected_len = 0;
        }
        s->session->ext.max_early_data = s->max_early_data;
    }

    if (tctx->generate_ticket_cb != NULL && tctx->generate_ticket_cb(SSL_CONNECTION_GET_USER_SSL(s), tctx->ticket_cb_data) == 0) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        goto err;
    }
    /*
     * If we are using anti-replay protection then we behave as if
     * SSL_OP_NO_TICKET is set - we are caching tickets anyway so there
     * is no point in using full stateless tickets.
     */
    if (SSL_CONNECTION_IS_VERSION13(s)
        && ((s->options & SSL_OP_NO_TICKET) != 0
            || (s->max_early_data > 0
                && (s->options & SSL_OP_NO_ANTI_REPLAY) == 0))) {
        if (!construct_stateful_ticket(s, pkt, age_add_u.age_add, tick_nonce)) {
            /* SSLfatal() already called */
            goto err;
        }
    } else {
        CON_FUNC_RETURN tmpret;

        tmpret = construct_stateless_ticket(s, pkt, age_add_u.age_add,
            tick_nonce);
        if (tmpret != CON_FUNC_SUCCESS) {
            if (tmpret == CON_FUNC_DONT_SEND) {
                /* Non-fatal. Abort construction but continue */
                ret = CON_FUNC_DONT_SEND;
                /* We count this as a success so update the counts anwyay */
                tls_update_ticket_counts(s);
            }
            /* else SSLfatal() already called */
            goto err;
        }
    }

    if (SSL_CONNECTION_IS_VERSION13(s)) {
        if (!tls_construct_extensions(s, pkt,
                SSL_EXT_TLS1_3_NEW_SESSION_TICKET,
                NULL, 0)) {
            /* SSLfatal() already called */
            goto err;
        }
        tls_update_ticket_counts(s);
        ssl_update_cache(s, SSL_SESS_CACHE_SERVER);
    }

    ret = CON_FUNC_SUCCESS;
err:
    return ret;
}

/*
 * In TLSv1.3 this is called from the extensions code, otherwise it is used to
 * create a separate message. Returns 1 on success or 0 on failure.
 */
int tls_construct_cert_status_body(SSL_CONNECTION *s, OCSP_RESPONSE *resp, WPACKET *pkt)
{
    unsigned char *respder = NULL;
    int resplen = 0;

    if (!WPACKET_put_bytes_u8(pkt, s->ext.status_type)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return 0;
    }

#ifndef OPENSSL_NO_OCSP
    resplen = i2d_OCSP_RESPONSE(resp, &respder);
#endif

    if (!WPACKET_sub_memcpy_u24(pkt, respder, resplen)) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        OPENSSL_free(respder);
        return 0;
    }

    OPENSSL_free(respder);
    return 1;
}

CON_FUNC_RETURN tls_construct_cert_status(SSL_CONNECTION *s, WPACKET *pkt)
{
    OCSP_RESPONSE *resp;

    resp = ossl_get_ocsp_response(s, 0);

    if (resp == NULL)
        return CON_FUNC_DONT_SEND;

    if (!tls_construct_cert_status_body(s, resp, pkt)) {
        /* SSLfatal() already called */
        return CON_FUNC_ERROR;
    }

    return CON_FUNC_SUCCESS;
}

#ifndef OPENSSL_NO_NEXTPROTONEG
/*
 * tls_process_next_proto reads a Next Protocol Negotiation handshake message.
 * It sets the next_proto member in s if found
 */
MSG_PROCESS_RETURN tls_process_next_proto(SSL_CONNECTION *s, PACKET *pkt)
{
    PACKET next_proto, padding;
    size_t next_proto_len;

    /*-
     * The payload looks like:
     *   uint8 proto_len;
     *   uint8 proto[proto_len];
     *   uint8 padding_len;
     *   uint8 padding[padding_len];
     */
    if (!PACKET_get_length_prefixed_1(pkt, &next_proto)
        || !PACKET_get_length_prefixed_1(pkt, &padding)
        || PACKET_remaining(pkt) > 0) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_MISMATCH);
        return MSG_PROCESS_ERROR;
    }

    if (!PACKET_memdup(&next_proto, &s->ext.npn, &next_proto_len)) {
        s->ext.npn_len = 0;
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return MSG_PROCESS_ERROR;
    }

    s->ext.npn_len = (unsigned char)next_proto_len;

    return MSG_PROCESS_CONTINUE_READING;
}
#endif

static CON_FUNC_RETURN tls_construct_encrypted_extensions(SSL_CONNECTION *s,
    WPACKET *pkt)
{
    if (!tls_construct_extensions(s, pkt, SSL_EXT_TLS1_3_ENCRYPTED_EXTENSIONS,
            NULL, 0)) {
        /* SSLfatal() already called */
        return CON_FUNC_ERROR;
    }

    return CON_FUNC_SUCCESS;
}

MSG_PROCESS_RETURN tls_process_end_of_early_data(SSL_CONNECTION *s, PACKET *pkt)
{
    if (PACKET_remaining(pkt) != 0) {
        SSLfatal(s, SSL_AD_DECODE_ERROR, SSL_R_LENGTH_MISMATCH);
        return MSG_PROCESS_ERROR;
    }

    if (s->early_data_state != SSL_EARLY_DATA_READING
        && s->early_data_state != SSL_EARLY_DATA_READ_RETRY) {
        SSLfatal(s, SSL_AD_INTERNAL_ERROR, ERR_R_INTERNAL_ERROR);
        return MSG_PROCESS_ERROR;
    }

    /*
     * EndOfEarlyData signals a key change so the end of the message must be on
     * a record boundary.
     */
    if (RECORD_LAYER_processed_read_pending(&s->rlayer)) {
        SSLfatal(s, SSL_AD_UNEXPECTED_MESSAGE, SSL_R_NOT_ON_RECORD_BOUNDARY);
        return MSG_PROCESS_ERROR;
    }

    s->early_data_state = SSL_EARLY_DATA_FINISHED_READING;
    if (!SSL_CONNECTION_GET_SSL(s)->method->ssl3_enc->change_cipher_state(s,
            SSL3_CC_HANDSHAKE | SSL3_CHANGE_CIPHER_SERVER_READ)) {
        /* SSLfatal() already called */
        return MSG_PROCESS_ERROR;
    }

    return MSG_PROCESS_CONTINUE_READING;
}
